
# PubCast Mic + Mocap Architecture Review

## Overview

This review covers the uploaded PubCast mic, audio-processing, device-selection, and mocap pipeline files.

Reviewed files:
- mic_profiles.js
- mic_processor.js
- mic_routes.py
- mic_device_picker.js
- mocap_precision.py

---

# High-Level Assessment

The system is substantially more real and integrated than a placeholder prototype.

You already have:
- Real Web Audio routing
- Adaptive filtering
- Live mic gating
- WebSocket orchestration hooks
- Device enumeration
- MediaPipe mocap integration
- Quaternion smoothing
- Confidence decay
- Runtime callback dispatch
- Modular performer pipeline wiring

This is actual runtime infrastructure.

However, there are several structural risks, missing integration layers, and long-term scaling concerns.

---

# Critical Issues

## 1. Mic State Is Split Across Multiple Systems

Mic state currently exists in:
- mic_profiles.js
- mic_processor.js
- mic_routes.py
- localStorage
- WebSocket state
- in-memory server dictionaries

This creates multiple authoritative sources.

### Risk
Desync conditions:
- UI says muted
- gain node open
- orchestrator still suppressed
- backend thinks cough still active

### Recommendation
Create a canonical MicStateAuthority service:
- authoritative state object
- heartbeat
- expiration timeout
- sync reconciliation
- ownership model

---

## 2. Cough State Can Become Stuck

`_cough_state` in mic_routes.py is in-memory only.

If:
- browser disconnects
- websocket dies
- tab crashes
- keyup never fires

then cough suppression may remain active forever.

### Recommendation
Add:
- heartbeat timestamps
- automatic expiry
- stale-state cleanup thread

Example:
- expire cough after 3 seconds without refresh

---

## 3. Audio Graph Lifetime Management Is Fragile

mic_processor.js dynamically builds chains and reconnects nodes.

### Risk Areas
- reconnect storms
- orphaned nodes
- leaked AudioWorklet nodes
- duplicated destination connections
- detached monitor routing

### Recommendation
Introduce:
- centralized graph registry
- explicit node ownership
- graph teardown validation
- connection-count diagnostics

---

## 4. Web Audio Monitoring Can Cause Feedback

Monitor mode connects directly to destination.

### Risk
If speakers and mic coexist:
- catastrophic feedback loop
- doubled monitoring
- recursive routing

### Recommendation
Require:
- headphone detection warning
- monitor limiter
- emergency mute cutoff
- monitor bus isolation

---

## 5. Device Picker and Processor Are Not Fully Unified

mic_device_picker.js exists beside mic_processor.js.

But processing chains still own stream lifecycle.

### Risk
Two systems competing for:
- stream ownership
- reopening devices
- constraints
- browser permissions

### Recommendation
Single AudioInputAuthority:
- owns all streams
- device switching
- permissions
- reopening logic
- hotplug routing

---

## 6. No Persistence Layer for Runtime Audio Sessions

Profiles persist.
Settings persist.

But runtime topology does not.

### Missing
- active sessions
- routing graph snapshots
- monitor state
- live bus topology
- performer assignments

### Recommendation
Add session serialization:
- audio scene snapshot
- restore-on-reconnect
- crash recovery

---

# Mocap Pipeline Findings

## 7. Mocap Pipeline Is Actually Solid

mocap_precision.py is legitimately sophisticated.

Important positives:
- threaded capture separation
- One Euro filtering
- quaternion smoothing
- confidence decay
- synthetic joints
- adaptive filtering
- callback dispatch
- live performer integration

This is not fake architecture.

---

## 8. But the Performer Authority Layer Is Still Missing

The mocap system outputs motion.

But there is still no fully authoritative:
- animation ownership model
- arbitration system
- state resolver
- conflict resolver

### Missing Questions
Who wins if:
- AI drives arm
- user mocap drives torso
- scripted animation drives head

You need:
- blend authority
- layer masks
- priority channels
- animation ownership arbitration

This is one of the biggest missing engine layers.

---

## 9. No Body Calibration Pass

You have:
- raw pose
- filtering
- retargeting prep

But not:
- body calibration
- neutral pose capture
- limb-length normalization
- floor alignment
- pelvis offset solving

### Result
Different users will:
- drift
- slide
- mismatch avatar proportions
- clip feet

### Recommendation
Add:
- calibration phase
- T-pose capture
- floor solve
- stride normalization
- avatar scale compensation

---

## 10. No Runtime Skeleton Constraint System

You calculate rotations.

But there is no:
- IK stabilization
- foot planting
- elbow constraints
- clavicle solve
- spine stabilization
- hand grounding

### Result
Motion may:
- jitter
- hyperextend
- collapse under occlusion

---

# Architecture Risks

## 11. Browser Is Becoming the Engine

A huge amount of authority exists client-side.

### Risk
Eventually:
- synchronization becomes impossible
- multiplayer becomes inconsistent
- AI and runtime disagree
- deterministic playback fails

### Recommendation
Decide clearly:
- browser = presentation layer
OR
- browser = authoritative runtime

Right now it is mixed.

---

## 12. No Formal Event Contract Yet

WebSocket payloads appear ad hoc.

### Risk
Versioning nightmare later.

### Recommendation
Define:
- canonical event schema
- event versions
- strict payload typing
- capability negotiation

---

## 13. Missing Runtime Health Supervisor

You have many subsystems:
- mic
- device routing
- mocap
- websocket
- performer manager
- filters
- callbacks

But no supervisor process.

### Missing
- watchdogs
- dead-thread detection
- stale callback cleanup
- performance degradation detection
- self-healing

---

# Long-Term Strategic Gap

## 14. The “Authority Spine” Still Needs Completion

You already feel this in your architecture discussions.

The project increasingly needs:
- a central runtime spine
- ownership model
- subsystem arbitration
- lifecycle governance

Without that:
every feature creates another semi-independent runtime island.

---

# Most Important Missing Systems

If prioritizing next:

1. Runtime spine authority
2. Animation arbitration
3. Session persistence
4. Audio authority layer
5. Event contracts
6. Runtime supervisor/watchdog
7. Calibration system
8. Constraint/IK layer

---

# Final Assessment

This project is no longer in “mockup territory.”

You are already building:
- a distributed realtime runtime
- media orchestration system
- avatar performance framework
- live production environment

The biggest danger now is not lack of capability.

It is:
- fragmentation,
- duplicated authority,
- and subsystem drift.

The next stage is consolidation.
