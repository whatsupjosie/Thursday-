# PodCast AI Custom Voxel Engine — System Analysis & Optimization Roadmap
**Status:** Architecture reviewed | Stubs identified | Quality bottlenecks located  
**Date:** May 12, 2026  
**For:** Next Claude iteration  

---

## EXECUTIVE SUMMARY

**What We Have:**
- **Rust Camera Engine** (`engine.rs`): Rock-solid virtual studio camera orchestration. 6 cameras, role assignment, frustum culling, scene truth distribution.
- **Python Distributed Engine** (2 versions): Twin-node architecture for broadcast + camera-assist processing. IRM adaptive batching, circuit breaker fault tolerance.
- **Character Engine** (`character_engine.py`): AI bot dialogue, speaking slot enforcement, thought logging. Perfect implementation.
- **Lighting Engine** (`lighting_engine.py`): Cinematic lighting control (key/fill/rim, volumetrics, bloom, color grading). Comprehensive state model.
- **HTML Control Room**: WebSocket-driven broadcast control interface.

**The Problem:**
The **voxel render pipeline is stubbed out**. In `distributed_engine.py` lines 612-616, `_do_voxel_render()` just sleeps 1ms and returns empty bytes. This is why character visual quality is bottlenecked — there's no actual high-fidelity voxel-to-mesh conversion, LOD system, or GPU acceleration.

---

## ARCHITECTURE OVERVIEW

### Data Flow
```
Scene Runtime (JSON transforms) 
    ↓
Rust Camera Engine (distribute_scene_truth)
    ├→ Frustum culling (what each camera sees)
    ├→ Priority detection (important objects first)
    └→ Transform updates to world
    ↓
Python Distributed Engine (primary node)
    ├→ IRM batching optimizer
    ├→ Work distribution (voxel_render, mesh_generate, video_encode)
    └→ Circuit breaker + fault tolerance
    ↓
**[MISSING: Real Voxel Render Implementation]**
    ├→ Voxel model loading (from character storage)
    ├→ High-poly mesh generation (decimation at distance)
    ├→ LOD system (4+ quality levels)
    ├→ Per-vertex lighting calculation
    └→ GPU texture atlasing
    ↓
Camera packets (camera pose + rendered frame data)
    ↓
WebSocket broadcast → Control Room UI
```

---

## KEY FILES & THEIR PURPOSE

| File | Purpose | Status | Priority |
|------|---------|--------|----------|
| `engine.rs` | Virtual camera authority | ✅ Complete | N/A |
| `distributed_engine.py` | Work distribution + async orchestration | ⚠️ Stubs in voxel pipeline | HIGH |
| `distributed_engine_node_trio_ready_apr12_2026.py` | Async version (trio-ready but not yet active) | ⚠️ Alternative path | MEDIUM |
| `character_engine.py` | Bot dialogue, speaking slots, thought logging | ✅ Complete | N/A |
| `lighting_engine.py` | Cinematic light control | ✅ Complete (need integration) | MEDIUM |
| `Enhanced_control_room_HTML_integration.html` | UI control panel | ⚠️ Needs voxel data from pipeline | HIGH |

---

## ROOT CAUSE: VOXEL RENDER STUB

**Location:** `distributed_engine.py:612-616`
```python
async def _do_voxel_render(self, work: WorkUnit) -> bytes:
    """Render voxels (placeholder for actual implementation)"""
    await asyncio.sleep(0.001)  # Simulate work
    return b"rendered"
```

**Impact:**
- No actual voxel data is being generated
- Characters appear as wireframes or placeholders
- No LOD system (same detail at 5m vs 50m)
- Lighting calculations skipped
- GPU acceleration not utilized

---

## QUALITY IMPROVEMENTS NEEDED

### Tier 1: Core Rendering (CRITICAL)
1. **Voxel Model Storage & Loading**
   - Characters stored as sparse voxel grids (min 16×16×16, up to 128×128×128)
   - Format: Binary RLE (run-length encoded) for compression
   - Load from disk → GPU memory with mipmaps

2. **High-Quality Mesh Generation**
   - Marching Cubes or Dual Contouring for smooth voxel-to-mesh conversion
   - Vertex normals for realistic lighting
   - UV mapping for texture atlasing
   - **Deadline:** <50ms per character per frame (60fps target)

3. **LOD (Level of Detail) System**
   - LOD0: Full detail (8k triangles) — close-up (0-2m)
   - LOD1: Medium (2k triangles) — medium shot (2-6m)
   - LOD2: Low (500 triangles) — wide shot (6-15m)
   - LOD3: Billboard (2 triangles) — distance (15m+)
   - **Auto-switch based on camera distance**

### Tier 2: Lighting & Shading (IMPORTANT)
1. **Per-Vertex Lighting**
   - Key light contribution (high-poly voxel-space normals)
   - Fill light softness
   - Rim light thickness
   - Ambient occlusion approximation
   - **Integrate with lighting_engine.py LightState**

2. **GPU Texture Atlasing**
   - Pack character textures into single atlas
   - Reduce draw calls (batch render 6 cameras in one pass)
   - Support streaming (load/unload as needed)

### Tier 3: Performance Optimization (SHOULD-HAVE)
1. **Batch Processing**
   - Queue up voxel renders for multiple characters
   - Process 4-8 characters per GPU kernel call
   - Use IRM adaptive batching (already implemented)

2. **Distributed Rendering**
   - Primary engine: HIGH quality (all 6 cameras, full LOD0)
   - Camera2 assist: MEDIUM quality (2 cameras, LOD1)
   - Camera3 assist: LOW quality (1 camera, LOD2)
   - **Graceful degradation under load**

3. **Caching & Reuse**
   - Cache LOD meshes after first generation
   - Reuse matrices/transforms across frames
   - Keep character meshes in GPU VRAM (persistent)

---

## IMPLEMENTATION PRIORITIES

### Phase 1: GET IT WORKING (Week 1)
**Goal:** Replace stub with real voxel render

1. Implement `_do_voxel_render()` in `distributed_engine.py`:
   ```python
   async def _do_voxel_render(self, work: WorkUnit) -> bytes:
       # Unpack work metadata: character_id, quality_level, camera_distance
       # Load voxel model from disk/cache
       # Run marching cubes → mesh
       # Calculate lighting per vertex
       # Return serialized mesh (bytes)
   ```

2. Create `voxel_renderer.py` module:
   - `VoxelModel` class (load from .vox/.vxl format)
   - `MeshGenerator` class (voxel→mesh conversion)
   - `LODSelector` class (distance-based LOD switching)

3. Test with one character (Pete)

### Phase 2: QUALITY PASS (Week 2)
**Goal:** LOD system + proper lighting

1. Implement full LOD pipeline
2. Integrate with `lighting_engine.py` light state
3. Add per-vertex normal calculation
4. Benchmark: target <30ms per frame per camera

### Phase 3: SCALE & OPTIMIZE (Week 3)
**Goal:** Handle 6 cameras + 3+ characters simultaneously

1. Batch voxel rendering across characters
2. GPU acceleration (CUDA/OptiX if available)
3. Distributed rendering (split across camera nodes)
4. Cache mesh persistence in VRAM

---

## TECHNICAL DECISIONS NEEDED

### Input Format for Voxel Models
- **Option A:** MagicaVoxel `.vox` format (human-editable, ~2MB per character)
- **Option B:** Custom binary RLE (compressed, ~500KB per character)
- **Option C:** Both (convert .vox → RLE at build time)
→ **Recommendation:** Option C (design-time flexibility, runtime efficiency)

### Mesh Generation Algorithm
- **Option A:** Marching Cubes (standard, known limitations at edges)
- **Option B:** Dual Contouring (smoother, handles thin features better)
- **Option C:** Greedy surface reconstruction (simplest, fast)
→ **Recommendation:** Dual Contouring (best quality/performance tradeoff)

### GPU Acceleration
- **Option A:** PyTorch CUDA kernels (if GPU available, fallback to CPU)
- **Option B:** CuPy (low-level, direct CUDA control)
- **Option C:** CPU-only with Numba JIT (simpler, slower)
→ **Recommendation:** Option A (PyTorch + fallback, same as other ML pipelines)

### Distribution Strategy
- **Primary:** Always renders all cameras at LOD0 (high quality)
- **Backup50:** Renders 3 cameras at LOD1 if primary >75% CPU
- **Backup100:** Renders 1 camera at LOD2 if primary >85% CPU
- **Quality_Reduced:** Renders all at LOD2 if >95% CPU
→ **Uses existing IRM + circuit breaker (already in place)**

---

## PERFORMANCE TARGETS

| Metric | Current (Stub) | Target | Notes |
|--------|---|---|---|
| Voxel render latency | 1ms (simulated) | <30ms per char | 6 cameras × 5 chars = 150ms budget/frame @ 60fps |
| Memory per character | ~100KB (voxel) | ~2-5MB (LOD meshes cached) | Keep LOD0+LOD1 in VRAM, stream LOD2/3 |
| GPU VRAM usage | None | <1GB | 6 characters × 5 LOD levels × ~100MB = feasible |
| FPS stability | N/A (stub) | 60fps constant | No frame drops during takes |
| Distributed overhead | <10ms | <10ms | Keep IRM batching overhead minimal |

---

## NEXT STEPS FOR NEXT CLAUDE

1. **Read this file first** (you are here)
2. **Review the code:**
   - Start: `distributed_engine.py` lines 612-650 (work processing)
   - Then: `engine.rs` lines 86-123 (scene distribution architecture)
   - Then: `lighting_engine.py` lines 1-150 (light state model)
3. **Create `voxel_renderer.py`:**
   - Stub classes first (VoxelModel, MeshGenerator, LODSelector)
   - Implement MagicaVoxel loader
   - Implement Dual Contouring mesh generation
   - Implement LOD system
4. **Integrate with distributed engine:**
   - Replace `_do_voxel_render()` stub with real implementation
   - Connect to lighting_engine.py light state
   - Add caching layer
5. **Test with single character → Scale to 3+**
6. **Benchmark & optimize using IRM adaptive batching**

---

## KEY CONSTRAINTS

- ✅ **Audio Never Sacrificed** — voxel rendering must not block audio thread
- ✅ **6 Camera Sync** — all cameras must render in <16.6ms (60fps)
- ✅ **Distributed Fallback** — quality degrades, doesn't break
- ✅ **Character Continuity** — mesh generation deterministic (same input → same output)
- ✅ **WebSocket Real-Time** — rendered data must stream to control room UI

---

## INTEGRATION POINTS

| System | Data Flow | Status |
|--------|-----------|--------|
| Rust Camera Engine | Transform updates → Frustum culling | ✅ Ready |
| Character Engine (AI) | Character metadata (id, position, emotion) | ✅ Ready |
| Lighting Engine | LightState object (key/fill/rim intensity, color) | ✅ Ready, need consumer |
| Distributed Engine | Work queue, IRM batching, circuit breaker | ✅ Ready, need voxel_render impl |
| Control Room UI | WebSocket with serialized mesh data | ⚠️ Waiting for mesh output |

---

## SUCCESS CRITERIA

- [ ] `_do_voxel_render()` returns actual mesh data (not empty bytes)
- [ ] LOD system switches based on camera distance
- [ ] Lighting applied per-vertex (key + fill + rim)
- [ ] 6 cameras simultaneously render at 60fps without frame drops
- [ ] Character quality visually improves (before: placeholder, after: cinematic)
- [ ] Distributed rendering activates under load (<10% quality loss)
- [ ] Control room UI displays rendered characters correctly

---

## FILES IN THIS HANDOFF

- `SYSTEM_ANALYSIS.md` (this file)
- `engine.rs` (Rust camera engine — reference)
- `character_engine.py` (character AI — reference)
- `lighting_engine.py` (lighting control — integrate with)
- `distributed_engine.py` (main distributed system — modify)
- `distributed_engine_node_trio_ready_apr12_2026.py` (async alternative for future)
- `Enhanced_control_room_HTML_integration.html` (UI frontend — waiting for data)

---

## OPEN QUESTIONS FOR NEXT CLAUDE

1. Do character voxel models already exist in a data directory, or need to be created?
2. Is there a target voxel resolution (16^3 vs 128^3)?
3. Should GPU acceleration be required or optional fallback?
4. What's the maximum number of simultaneous characters in a scene?
5. Any existing mesh format preference (gltf, obj, proprietary)?

---

**End Analysis**
