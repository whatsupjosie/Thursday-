// src/engine.rs — The Camera Engine
// Orchestrates all virtual cameras + the scene world.
// This is the single authoritative camera authority in Rust.
use std::collections::HashMap;
use serde_json::Value;
use crate::camera::{VirtualCamera, CameraRole, CameraStatusReport, LensProfile};
use crate::world::{SceneWorld, Transform3D, create_studio_world};
use crate::packet::CameraPacket;
use crate::shot::{ShotSpec, TargetSpec, ShotQueue};
use crate::fallback::FallbackLevel;

pub struct CameraEngine {
    cameras:    HashMap<String, VirtualCamera>,
    world:      SceneWorld,
    program_id: Option<String>,
    preview_id: Option<String>,
    scene_id:   Option<String>,
    take_number: u32,
}

impl CameraEngine {
    pub fn new() -> Self {
        Self {
            cameras:    HashMap::new(),
            world:      create_studio_world(),
            program_id: None,
            preview_id: None,
            scene_id:   None,
            take_number: 0,
        }
    }

    pub fn register(&mut self, cam: VirtualCamera) {
        self.cameras.insert(cam.camera_id().to_string(), cam);
    }

    pub fn get(&self, id: &str) -> Option<&VirtualCamera> { self.cameras.get(id) }
    pub fn get_mut(&mut self, id: &str) -> Option<&mut VirtualCamera> { self.cameras.get_mut(id) }

    pub fn set_program(&mut self, id: &str) -> bool {
        if !self.cameras.contains_key(id) { return false; }
        if let Some(old) = &self.program_id.clone() {
            if old != id { if let Some(c) = self.cameras.get_mut(old) { c.assign_role(CameraRole::Standby); } }
        }
        if let Some(c) = self.cameras.get_mut(id) { c.assign_role(CameraRole::Program); }
        self.program_id = Some(id.to_string());
        true
    }

    pub fn set_preview(&mut self, id: &str) -> bool {
        if !self.cameras.contains_key(id) { return false; }
        if let Some(old) = &self.preview_id.clone() {
            if old != id { if let Some(c) = self.cameras.get_mut(old) { c.assign_role(CameraRole::Standby); } }
        }
        if let Some(c) = self.cameras.get_mut(id) { c.assign_role(CameraRole::Preview); }
        self.preview_id = Some(id.to_string());
        true
    }

    /// Execute a cut: preview → program
    pub fn take(&mut self) -> bool {
        let pvw = match &self.preview_id { None => return false, Some(id) => id.clone() };
        // Complete current program shot
        if let Some(pgm_id) = &self.program_id.clone() {
            if let Some(c) = self.cameras.get_mut(pgm_id) {
                c.complete_shot();
                c.assign_role(CameraRole::Standby);
            }
        }
        if let Some(c) = self.cameras.get_mut(&pvw) { c.assign_role(CameraRole::Program); }
        self.program_id = Some(pvw);
        self.preview_id = None;
        true
    }

    /// Distribute scene assignments to cameras
    pub fn assign_scene(&mut self, scene_id: &str, take: u32, assignments: HashMap<String, Vec<ShotSpec>>) {
        self.scene_id    = Some(scene_id.to_string());
        self.take_number = take;
        for (cam_id, shots) in assignments {
            if let Some(cam) = self.cameras.get_mut(&cam_id) {
                cam.load_shots(shots, scene_id);
            }
        }
    }

    /// Update world object position (called by scene runtime)
    pub fn update_object(&mut self, obj_id: &str, transform: Transform3D) {
        self.world.update_transform(obj_id, transform, 0.02);
    }

    /// Push scene truth to all virtual cameras (called each tick)
    pub fn distribute_scene_truth(&mut self) {
        let camera_ids: Vec<String> = self.cameras.keys().cloned().collect();
        for cam_id in camera_ids {
            let cam_transform;
            let cam_yaw;
            let cam_fov;
            {
                let cam = &self.cameras[&cam_id];
                cam_transform = cam.transform;
                cam_yaw       = cam.transform.yaw;
                cam_fov       = cam.lens.fov_degrees;
            }
            // Query world for this camera's frustum
            let visible = self.world.objects_in_frustum(&cam_transform, cam_yaw, cam_fov, 15.0);
            let priority = self.world.priority_subjects_in_frustum(&cam_transform, cam_yaw, cam_fov, 12.0);

            let visible_ids: Vec<String>   = visible.iter().map(|o| o.object_id.clone()).collect();
            let priority_ids: Vec<String>  = priority.iter().map(|o| o.object_id.clone()).collect();
            let cue_flags: Vec<String>     = visible.iter().filter(|o| o.cue_armed)
                .map(|o| format!("cue:{}", o.object_id)).collect();

            if let Some(cam) = self.cameras.get_mut(&cam_id) {
                cam.receive_scene_truth(visible_ids, priority_ids, cue_flags, Vec::new());
                // Auto-target primary subject for AI-operated cameras
                if let Some(first) = priority.first() {
                    let t = first.transform;
                    cam.set_target(&first.object_id, t);
                }
            }
        }
    }

    /// Tick all camera movements (call ~30fps)
    pub fn tick(&mut self) {
        self.distribute_scene_truth();
        let ids: Vec<String> = self.cameras.keys().cloned().collect();
        for id in ids {
            if let Some(cam) = self.cameras.get_mut(&id) {
                cam.tick_follow();
            }
        }
    }

    /// Emit packets from all cameras
    pub fn emit_all_packets(&self) -> Vec<CameraPacket> {
        self.cameras.values().map(|c| c.emit_packet()).collect()
    }

    pub fn emit_program_packet(&self) -> Option<CameraPacket> {
        self.program_id.as_ref().and_then(|id| self.cameras.get(id)).map(|c| c.emit_packet())
    }

    pub fn all_status(&self) -> Vec<CameraStatusReport> {
        self.cameras.values().map(|c| c.report_status()).collect()
    }

    pub fn world_json(&self) -> Value { self.world.to_json() }

    pub fn status_json(&self) -> Value {
        let cameras: Vec<Value> = self.cameras.values().map(|c| c.to_dict_json()).collect();
        serde_json::json!({
            "scene_id":    self.scene_id,
            "take_number": self.take_number,
            "program":     self.program_id,
            "preview":     self.preview_id,
            "cameras":     cameras,
            "world_objects": self.world.object_count(),
        })
    }
}

impl Default for CameraEngine {
    fn default() -> Self { Self::new() }
}

/// Build the standard PubCast virtual camera lineup
pub fn create_pubcast_cameras() -> CameraEngine {
    use crate::camera::VirtualCamera;
    use crate::world::Transform3D;

    let mut engine = CameraEngine::new();

    engine.register(VirtualCamera::new(
        "wide_shot", "Wide Shot", CameraRole::Program,
        Transform3D { x: 0.0, y: 2.0, z: 6.0, pitch: -8.0, ..Default::default() },
        LensProfile::wide(),
    ));

    engine.register(VirtualCamera::new(
        "medium_shot", "Medium Shot", CameraRole::Preview,
        Transform3D { x: 2.0, y: 1.5, z: 3.5, yaw: -15.0, pitch: -5.0, ..Default::default() },
        LensProfile::medium(),
    ));

    engine.register(VirtualCamera::new(
        "close_up", "Close Up", CameraRole::Standby,
        Transform3D { x: 0.5, y: 1.2, z: 2.0, yaw: -5.0, pitch: -3.0, ..Default::default() },
        LensProfile::close_up(),
    ));

    engine.register(VirtualCamera::new(
        "overhead", "Overhead", CameraRole::Standby,
        Transform3D { x: 0.0, y: 6.0, z: 0.5, pitch: 88.0, ..Default::default() },
        LensProfile::overhead(),
    ));

    engine.register(VirtualCamera::new(
        "reaction_l", "Reaction Left", CameraRole::Standby,
        Transform3D { x: -2.8, y: 1.5, z: 3.0, yaw: 25.0, pitch: -4.0, ..Default::default() },
        LensProfile::medium(),
    ));

    engine.register(VirtualCamera::new(
        "reaction_r", "Reaction Right", CameraRole::Standby,
        Transform3D { x: 2.8, y: 1.5, z: 3.0, yaw: -25.0, pitch: -4.0, ..Default::default() },
        LensProfile::medium(),
    ));

    engine.set_program("wide_shot");
    engine.set_preview("medium_shot");

    engine
}
