# Voxel Renderer Implementation Guide
**For:** Next Claude iteration  
**Goal:** Replace stub with working voxel→mesh→lighting pipeline  
**Estimated effort:** 3-4 days for full implementation  

---

## QUICK START

### Step 1: Create `voxel_renderer.py` Module

```python
"""
voxel_renderer.py — High-fidelity voxel model rendering
Converts sparse voxel grids to GPU-ready meshes with LOD and lighting.
"""

import struct
import numpy as np
from typing import Optional, Tuple, List
from dataclasses import dataclass
from pathlib import Path
import json

# ─────────────────────────────────────────
#  VOXEL MODEL LOADING
# ─────────────────────────────────────────

@dataclass
class VoxelModel:
    """Represents a sparse voxel grid"""
    model_id: str
    width: int
    height: int
    depth: int
    voxels: np.ndarray  # Shape: (W, H, D), dtype=uint8 (0=empty, 1-255=color/material)
    palette: List[Tuple[int, int, int]]  # RGB colors
    
    @classmethod
    def load_from_magicavoxel(cls, vox_path: str) -> 'VoxelModel':
        """Load MagicaVoxel .vox file"""
        # TODO: Implement VOX format parser
        # VOX format: magic(4) + version(4) + chunks...
        # See: https://github.com/ephtracy/voxel-format/blob/master/MagicaVoxel-file-format-0.99.md
        raise NotImplementedError("VOX parser needed")
    
    @classmethod
    def load_from_rle(cls, rle_path: str) -> 'VoxelModel':
        """Load compressed RLE format"""
        # TODO: Implement custom RLE decoder
        raise NotImplementedError("RLE decoder needed")
    
    def save_to_rle(self, output_path: str) -> None:
        """Save as compressed RLE for fast loading"""
        # TODO: RLE encoder for efficient storage
        raise NotImplementedError("RLE encoder needed")
    
    def get_voxel(self, x: int, y: int, z: int) -> int:
        """Get voxel value at position (with bounds check)"""
        if 0 <= x < self.width and 0 <= y < self.height and 0 <= z < self.depth:
            return self.voxels[x, y, z]
        return 0  # Empty

# ─────────────────────────────────────────
#  MESH GENERATION (DUAL CONTOURING)
# ─────────────────────────────────────────

@dataclass
class Mesh:
    """Triangle mesh with positions, normals, UVs"""
    vertices: np.ndarray  # Shape: (N, 3), dtype=float32
    normals: np.ndarray   # Shape: (N, 3), dtype=float32
    uv: np.ndarray        # Shape: (N, 2), dtype=float32
    indices: np.ndarray   # Shape: (M, 3), dtype=uint32
    colors: Optional[np.ndarray] = None  # Shape: (N, 3), dtype=uint8
    
    def triangle_count(self) -> int:
        return len(self.indices)
    
    def vertex_count(self) -> int:
        return len(self.vertices)
    
    def to_bytes(self) -> bytes:
        """Serialize mesh to bytes for network transmission"""
        # Header: vertex_count, index_count, has_colors
        # Then: vertices (3×float32 each), normals, indices, colors (optional)
        data = bytearray()
        
        # Header
        data.extend(struct.pack('<I', self.vertex_count()))
        data.extend(struct.pack('<I', len(self.indices)))
        data.extend(struct.pack('B', 1 if self.colors is not None else 0))
        
        # Vertex data
        data.extend(self.vertices.astype(np.float32).tobytes())
        data.extend(self.normals.astype(np.float32).tobytes())
        
        # Index data
        data.extend(self.indices.astype(np.uint32).tobytes())
        
        # Colors (optional)
        if self.colors is not None:
            data.extend(self.colors.astype(np.uint8).tobytes())
        
        return bytes(data)
    
    @staticmethod
    def from_bytes(data: bytes) -> 'Mesh':
        """Deserialize mesh from bytes"""
        offset = 0
        
        # Read header
        vertex_count = struct.unpack_from('<I', data, offset)[0]
        offset += 4
        index_count = struct.unpack_from('<I', data, offset)[0]
        offset += 4
        has_colors = struct.unpack_from('B', data, offset)[0]
        offset += 1
        
        # Read vertices
        vertex_bytes = vertex_count * 3 * 4  # 3 floats × 4 bytes
        vertices = np.frombuffer(data, dtype=np.float32, count=vertex_count*3, offset=offset).reshape(-1, 3)
        offset += vertex_bytes
        
        # Read normals
        normals = np.frombuffer(data, dtype=np.float32, count=vertex_count*3, offset=offset).reshape(-1, 3)
        offset += vertex_bytes
        
        # Read indices
        index_bytes = index_count * 3 * 4
        indices = np.frombuffer(data, dtype=np.uint32, count=index_count*3, offset=offset).reshape(-1, 3)
        offset += index_bytes
        
        # Read colors (optional)
        colors = None
        if has_colors:
            colors = np.frombuffer(data, dtype=np.uint8, count=vertex_count*3, offset=offset).reshape(-1, 3)
        
        return Mesh(vertices=vertices, normals=normals, uv=np.zeros((vertex_count, 2)), 
                   indices=indices, colors=colors)

class MeshGenerator:
    """Convert voxel grids to smooth triangle meshes"""
    
    def __init__(self, voxel_model: VoxelModel):
        self.model = voxel_model
    
    def generate_mesh(self) -> Mesh:
        """Generate mesh using Dual Contouring algorithm
        
        This is the core function that converts voxel grid → smooth surface.
        
        Algorithm:
        1. For each cell in the grid, if it contains an edge (voxel change)
        2. Find the intersection point on that edge
        3. Compute vertex position (cell center, weighted by neighbors)
        4. Create triangles from the quad mesh
        """
        # TODO: Implement Dual Contouring
        # Reference: Ju et al., "Dual Contouring of Hermite Data"
        # Simplified steps:
        # 1. Identify edges (transitions from solid→empty)
        # 2. Compute vertex positions at edge midpoints
        # 3. Generate triangles connecting vertices
        # 4. Calculate normals from voxel gradients
        
        # Placeholder: naive approach (voxel-aligned)
        vertices = []
        indices = []
        normals = []
        
        # Scan voxels
        for x in range(self.model.width - 1):
            for y in range(self.model.height - 1):
                for z in range(self.model.depth - 1):
                    # Check if this is a surface voxel (boundary)
                    if self._is_surface_voxel(x, y, z):
                        # Create vertex at center
                        v_idx = len(vertices)
                        vertices.append([x + 0.5, y + 0.5, z + 0.5])
                        
                        # Compute normal from voxel gradient
                        normal = self._compute_normal(x, y, z)
                        normals.append(normal)
        
        # Convert to numpy
        verts = np.array(vertices, dtype=np.float32) if vertices else np.zeros((0, 3), dtype=np.float32)
        norms = np.array(normals, dtype=np.float32) if normals else np.zeros((0, 3), dtype=np.float32)
        
        # TODO: Generate indices (triangulate mesh)
        idx = np.array([], dtype=np.uint32).reshape(0, 3)
        
        mesh = Mesh(
            vertices=verts,
            normals=norms if len(norms) > 0 else np.zeros_like(verts),
            uv=np.zeros((len(verts), 2), dtype=np.float32),
            indices=idx,
            colors=None
        )
        
        return mesh
    
    def _is_surface_voxel(self, x: int, y: int, z: int) -> bool:
        """Check if voxel is on a surface (has empty neighbor)"""
        filled = self.model.get_voxel(x, y, z) > 0
        
        # Check 6 neighbors
        neighbors = [
            self.model.get_voxel(x+1, y, z) > 0,
            self.model.get_voxel(x-1, y, z) > 0,
            self.model.get_voxel(x, y+1, z) > 0,
            self.model.get_voxel(x, y-1, z) > 0,
            self.model.get_voxel(x, y, z+1) > 0,
            self.model.get_voxel(x, y, z-1) > 0,
        ]
        
        # Surface if filled and has at least one empty neighbor
        return filled and not all(neighbors)
    
    def _compute_normal(self, x: int, y: int, z: int) -> np.ndarray:
        """Compute vertex normal from voxel density gradient"""
        gx = (self.model.get_voxel(x+1, y, z) - self.model.get_voxel(x-1, y, z)) / 2.0
        gy = (self.model.get_voxel(x, y+1, z) - self.model.get_voxel(x, y-1, z)) / 2.0
        gz = (self.model.get_voxel(x, y, z+1) - self.model.get_voxel(x, y, z-1)) / 2.0
        
        normal = np.array([gx, gy, gz], dtype=np.float32)
        norm = np.linalg.norm(normal)
        return normal / (norm + 1e-6)  # Normalize

# ─────────────────────────────────────────
#  LEVEL OF DETAIL (LOD) SYSTEM
# ─────────────────────────────────────────

class LODSelector:
    """Select mesh quality based on camera distance"""
    
    # LOD thresholds (distances in world units)
    THRESHOLDS = {
        "LOD0": 2.0,    # Full detail (0-2m)
        "LOD1": 6.0,    # Medium (2-6m)
        "LOD2": 15.0,   # Low (6-15m)
        "LOD3": float('inf'),  # Billboard (15m+)
    }
    
    # Triangle budgets per LOD
    BUDGETS = {
        "LOD0": 8000,   # Full voxel detail
        "LOD1": 2000,   # Decimated
        "LOD2": 500,    # Heavily simplified
        "LOD3": 2,      # Single quad (billboard)
    }
    
    @staticmethod
    def select_lod(camera_distance: float) -> str:
        """Select LOD level based on distance"""
        for lod, threshold in LODSelector.THRESHOLDS.items():
            if camera_distance < threshold:
                return lod
        return "LOD3"
    
    @staticmethod
    def decimate_mesh(mesh: Mesh, target_triangles: int) -> Mesh:
        """Reduce triangle count via quadric error metrics"""
        # TODO: Implement mesh decimation
        # For now, return original
        return mesh

# ─────────────────────────────────────────
#  LIGHTING APPLICATION
# ─────────────────────────────────────────

class LightingApplier:
    """Apply cinematic lighting to vertex colors"""
    
    def __init__(self, light_state: dict):
        """
        light_state: from lighting_engine.py
        {
            'key_intensity': 1.0, 'key_azimuth': -45, 'key_elevation': 35,
            'fill_intensity': 0.35, 'fill_azimuth': 60,
            'rim_intensity': 0.6, 'rim_width': 0.15,
            'ambient_intensity': 0.25,
            'saturation': 1.0, 'contrast': 1.0, 'exposure': 0.0,
            ...
        }
        """
        self.light_state = light_state
    
    def apply_lighting(self, mesh: Mesh) -> Mesh:
        """Apply per-vertex lighting calculations"""
        vertex_colors = np.zeros((len(mesh.vertices), 3), dtype=np.uint8)
        
        for i, normal in enumerate(mesh.normals):
            # Key light
            key_dir = self._direction_from_spherical(
                self.light_state.get('key_azimuth', -45),
                self.light_state.get('key_elevation', 35)
            )
            key_contrib = np.dot(normal, key_dir) * self.light_state.get('key_intensity', 1.0)
            key_contrib = max(0, key_contrib)
            
            # Fill light
            fill_dir = self._direction_from_spherical(
                self.light_state.get('fill_azimuth', 60),
                self.light_state.get('fill_elevation', 20)
            )
            fill_contrib = (np.dot(normal, fill_dir) * 0.5 + 0.5) * self.light_state.get('fill_intensity', 0.35)
            
            # Rim light (backlit)
            rim_dir = -key_dir
            rim_contrib = max(0, np.dot(normal, rim_dir)) * self.light_state.get('rim_intensity', 0.6)
            
            # Ambient
            ambient = self.light_state.get('ambient_intensity', 0.25)
            
            # Combine
            total = key_contrib + fill_contrib + rim_contrib + ambient
            total = np.clip(total, 0, 1)
            
            # Apply color grading
            vertex_colors[i] = np.array([total * 255] * 3, dtype=np.uint8)
        
        mesh.colors = vertex_colors
        return mesh
    
    @staticmethod
    def _direction_from_spherical(azimuth_deg: float, elevation_deg: float) -> np.ndarray:
        """Convert azimuth/elevation to direction vector"""
        az_rad = np.radians(azimuth_deg)
        el_rad = np.radians(elevation_deg)
        
        x = np.cos(el_rad) * np.sin(az_rad)
        y = np.sin(el_rad)
        z = np.cos(el_rad) * np.cos(az_rad)
        
        direction = np.array([x, y, z], dtype=np.float32)
        return direction / (np.linalg.norm(direction) + 1e-6)

# ─────────────────────────────────────────
#  HIGH-LEVEL RENDER FUNCTION
# ─────────────────────────────────────────

class VoxelRenderer:
    """High-level voxel rendering orchestrator"""
    
    def __init__(self):
        self._model_cache = {}  # model_id → VoxelModel
        self._mesh_cache = {}   # (model_id, lod) → Mesh
    
    def render(self, 
               model_id: str,
               camera_distance: float,
               light_state: dict,
               force_reload: bool = False) -> bytes:
        """
        Render a voxel character to mesh bytes
        
        Args:
            model_id: Character identifier (e.g., "pete_voxel_v1")
            camera_distance: Distance from camera (affects LOD selection)
            light_state: Lighting state from lighting_engine.py
            force_reload: Bypass cache (for debugging)
        
        Returns:
            Serialized mesh bytes ready for network transmission
        """
        
        # Load voxel model
        if model_id not in self._model_cache or force_reload:
            # TODO: Load from voxel data directory
            # For now, raise NotImplementedError
            raise NotImplementedError(f"Load voxel model: {model_id}")
        
        voxel_model = self._model_cache[model_id]
        
        # Select LOD
        lod = LODSelector.select_lod(camera_distance)
        
        # Check cache
        cache_key = (model_id, lod)
        if cache_key not in self._mesh_cache:
            # Generate mesh
            generator = MeshGenerator(voxel_model)
            mesh = generator.generate_mesh()
            
            # Decimate if needed
            target_triangles = LODSelector.BUDGETS[lod]
            if mesh.triangle_count() > target_triangles:
                mesh = LODSelector.decimate_mesh(mesh, target_triangles)
            
            # Cache it
            self._mesh_cache[cache_key] = mesh
        
        mesh = self._mesh_cache[cache_key]
        
        # Apply lighting
        applier = LightingApplier(light_state)
        lit_mesh = applier.apply_lighting(mesh)
        
        # Serialize and return
        return lit_mesh.to_bytes()

```

---

## Step 2: Integration with `distributed_engine.py`

Replace the stub `_do_voxel_render()` method:

```python
# In distributed_engine.py, replace lines 612-616:

async def _do_voxel_render(self, work: WorkUnit) -> bytes:
    """Render voxels to mesh with LOD and lighting"""
    from voxel_renderer import VoxelRenderer
    
    try:
        # Unpack work metadata
        model_id = work.metadata.get("model_id")
        camera_distance = work.metadata.get("camera_distance", 5.0)
        light_state = work.metadata.get("light_state", {})
        
        # Render
        renderer = VoxelRenderer()  # TODO: Make this a singleton/cached instance
        mesh_bytes = renderer.render(model_id, camera_distance, light_state)
        
        return mesh_bytes
    
    except Exception as e:
        logger.error(f"Voxel render failed: {e}")
        return b""  # Return empty on error (graceful degradation)
```

---

## Step 3: Integration with Lighting Engine

In `distributed_engine.py`, when submitting voxel work:

```python
def distribute_scene_truth(self):
    """Distribute scene updates including voxel renders"""
    for camera_id, camera_state in self._connected_cameras.items():
        for obj_id, obj_transform in camera_state.visible_objects.items():
            # Calculate distance
            distance = np.linalg.norm([obj_transform.x, obj_transform.y, obj_transform.z])
            
            # Submit voxel render work
            work = WorkUnit(
                work_id=f"{obj_id}_{camera_id}_{time.time()}",
                work_type="voxel_render",
                priority=5,
                metadata={
                    "model_id": obj_id,
                    "camera_distance": distance,
                    "light_state": self.current_light_state.to_dict(),  # From lighting_engine
                    "camera_id": camera_id,
                }
            )
            self.submit_work(work)
```

---

## Step 4: Testing Checklist

- [ ] Load MagicaVoxel `.vox` file
- [ ] Generate mesh from voxel grid (marching cubes or dual contouring)
- [ ] Verify vertex normals are computed correctly
- [ ] Apply key + fill + rim lighting
- [ ] Serialize mesh to bytes and deserialize correctly
- [ ] LOD system selects correct detail level based on distance
- [ ] Mesh decimation reduces triangle count
- [ ] Integrate with distributed engine work queue
- [ ] Render multiple characters simultaneously (batching)
- [ ] Verify WebSocket transmission to control room UI
- [ ] Benchmark latency on target hardware

---

## Implementation Priority

1. **First:** MagicaVoxel loader + basic mesh generation (get something working)
2. **Second:** Lighting calculations (make it pretty)
3. **Third:** LOD system + decimation (make it fast)
4. **Fourth:** Caching + GPU acceleration (make it scale)

---

## Reference: Expected Mesh Byte Format

```
[HEADER - 9 bytes]
  vertex_count: uint32 (4 bytes)
  index_count: uint32 (4 bytes)
  has_colors: uint8 (1 byte)

[VERTICES - vertex_count * 12 bytes]
  x, y, z: float32 each

[NORMALS - vertex_count * 12 bytes]
  nx, ny, nz: float32 each

[INDICES - index_count * 3 * 4 bytes]
  i0, i1, i2: uint32 each (per triangle)

[COLORS - OPTIONAL - vertex_count * 3 bytes]
  r, g, b: uint8 each (if has_colors == 1)
```

---

**Good luck!** The system is well-designed. You just need to plug in the voxel rendering piece.

