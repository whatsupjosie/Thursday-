# Included Context Notes

Key Architectural Direction:
- Stations are not menus. They are operational runtime entities.
- UI should feel like walking up to equipment, not opening software.
- Movement is emotionally meaningful only when tied to rooms, stations, and interactions.
- The runtime spine is the nervous system connecting rooms, performers, stations, cameras, lighting, and pub interactions.

High-Value Existing Systems:
- camera_control_ui.js
- lighting runtime/state systems
- modal system
- room transition concepts
- websocket infrastructure

Known Risks:
- duplicated UI utility logic
- fragmented authority ownership
- direct DOM mutation patterns
- inconsistent runtime state ownership
- transform/movement authority conflicts
- fragmented websocket event handling

Target Vertical Slice:
Spawn performer
→ enter pub
→ walk to bar
→ activate interaction
→ station publishes event
→ control room camera sees performer
→ room/state synchronization persists cleanly
