# PubCast Runtime Spine Handoff — Claude Engineering Task

You are working on PubCast AI, a spatial cinematic runtime environment with multiplayer performers, world-space stations, control-room systems, avatar traversal, and operational UI.

Your task is NOT to redesign the project.
Your task is to stabilize and unify the runtime architecture.

IMPORTANT CONTEXT
PubCast is evolving away from “web pages and menus” and toward a unified runtime world where:
- rooms are inhabitable spaces
- UI stations are operational objects
- performers move through the world
- stations publish runtime events
- camera systems, lighting, editing, and pub interactions all coexist inside one event-driven runtime spine

The project already contains:
- room/view switching
- camera control systems
- websocket infrastructure
- lighting systems
- editing panels
- modal systems
- station concepts
- avatar concepts
- world traversal concepts

However:
- authority is fragmented
- UI utilities are duplicated
- runtime state ownership is unclear
- movement authority is not canonical
- event flow is inconsistent
- systems communicate too directly

MISSION
Build the foundational Runtime Spine architecture.

DO NOT over-engineer.
DO NOT replace working systems unnecessarily.
DO NOT destroy existing workflows.
DO NOT introduce giant frameworks.

Your goal is:
- canonical event flow
- performer authority
- station registration
- runtime lifecycle consistency
- movement stabilization foundation
- UI convergence

PRIORITY ORDER

1. Build canonical event bus
2. Build performer authority layer
3. Build station registry system
4. Consolidate duplicated UI utility logic
5. Create movement-ready runtime lifecycle
6. Prepare for avatar/world traversal integration

TARGET ARCHITECTURE

runtime/
  spine/
    event_bus.py
    runtime_state.py
    station_registry.py
    performer_registry.py
    room_registry.py

    performers/
      performer_state.py
      locomotion.py
      movement_authority.py
      replication.py

    stations/
      base_station.py
      camera_station.py
      director_station.py
      pub_station.py

EVENT BUS REQUIREMENTS

Everything communicates through structured events.

Examples:
- performer:moved
- room:entered
- station:activated
- camera:live
- lighting:preset
- pub:interaction
- trivia:started

The event bus must support:
- subscribe
- unsubscribe
- emit
- async-safe operation if possible
- logging/debug visibility

PERFORMER SYSTEM REQUIREMENTS

Create canonical PerformerState objects.

A performer owns:
- position
- rotation
- velocity
- locomotion state
- interaction state
- current room
- active station
- replication timestamp
- avatar binding

Movement authority must become centralized.
No duplicate transform ownership.

STATION SYSTEM REQUIREMENTS

Stations are runtime-operational entities.
Not just menus.

Each station should:
- register itself
- subscribe to events
- emit events
- own local operational state
- mount/unmount cleanly

UI CONSOLIDATION

There are duplicated UI utility files for:
- switchView
- setupDrawer
- modal logic

Consolidate these carefully into canonical reusable runtime UI modules.

Do NOT break existing interfaces if avoidable.

FILES TO REVIEW FIRST

UI / Runtime:
- ui.js
- editor_ui.js
- camera_control_ui.js
- modal system files

Runtime concepts:
- lighting runtime files
- websocket handlers
- room switching systems
- station-related files

SEARCH FOR:
- duplicate switchView
- duplicate drawer handlers
- websocket state mutations
- local transform authority
- direct DOM state ownership
- fragmented runtime state

CRITICAL DESIGN RULES

1. One authoritative truth for performer transforms.
2. One canonical event flow.
3. Runtime state before UI state.
4. Stations are operational runtime objects.
5. World-space interaction is the long-term goal.
6. Preserve the existing creative direction.
7. Avoid framework bloat.
8. Build for extensibility, not premature complexity.

FIRST MILESTONE

Achieve this vertical slice:

- runtime event bus operational
- performer state object operational
- station registry operational
- camera station publishing events
- room transition events working
- movement-ready runtime lifecycle established

SECOND MILESTONE

Prepare for:
Spawn performer → enter room → activate station → emit runtime events → synchronize state → transition rooms cleanly.

DELIVERABLES

1. Runtime spine files
2. Refactored UI utility consolidation
3. Event architecture documentation
4. Performer authority documentation
5. Station lifecycle documentation
6. Notes on remaining movement integration work
7. Explicit warnings about fragile systems or unresolved authority conflicts

IMPORTANT
The project’s identity is already strong.
Your job is not to reinvent PubCast.
Your job is to make the runtime architecture worthy of the world that already exists.
