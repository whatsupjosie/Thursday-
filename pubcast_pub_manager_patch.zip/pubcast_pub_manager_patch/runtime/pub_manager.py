"""
PubCast Pub Manager
===================

Doctrine:
    The Pub Manager is declarative, not operational.

    It sets establishment posture and policy.
    It does not route packets, move avatars, open sockets, load assets,
    clean folders, kill processes, write saves directly, or bypass the Spine.

Role:
    Pete protects local production flow.
    E-Pete protects technical execution and engine routing.
    Jeeves protects order by shelving, tidying, restoring, and bookkeeping.
    The Spine protects authoritative truth.
    The Pub Manager protects establishment-wide continuity.

Design:
    Vitals in  -> establishment mode -> policy out -> event/status reporting.

This module is intentionally small and dependency-light so it can sit inside
PubCast's runtime spine without becoming a bottleneck or a god object.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, Iterable, Mapping, MutableMapping, Optional, Tuple


class EstablishmentMode(str, Enum):
    """High-level operating posture for the whole PubCast establishment."""

    OPEN = "open"
    QUIET = "quiet"
    BUSY = "busy"
    CROWDED = "crowded"
    LATE_NIGHT = "late_night"
    MAINTENANCE = "maintenance"
    RECOVERY = "recovery"
    EMERGENCY = "emergency"
    HIBERNATED = "hibernated"


class RiskLevel(str, Enum):
    """Simple risk label for doctor/status presentation."""

    NORMAL = "normal"
    WATCH = "watch"
    STRAINED = "strained"
    PROTECTED = "protected"
    RECOVERY = "recovery"
    EMERGENCY = "emergency"


@dataclass(frozen=True)
class PubVitals:
    """
    Establishment-wide telemetry snapshot.

    These are observations only. Passing vitals to the Pub Manager must not
    mutate runtime systems. Callers may construct this from resource monitors,
    session state, recording state, doctor reports, or spine-owned registries.
    """

    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    vram_percent: float = 0.0
    disk_percent: float = 0.0
    active_rooms: int = 0
    active_guests: int = 0
    active_recordings: int = 0
    active_ai_workers: int = 0
    degraded_services: int = 0
    failed_services: int = 0
    pending_heavy_jobs: int = 0
    idle_toolkits: int = 0
    is_maintenance_requested: bool = False
    is_shutdown_requested: bool = False
    recovery_requested: bool = False
    emergency_requested: bool = False
    notes: Tuple[str, ...] = field(default_factory=tuple)

    def normalized(self) -> "PubVitals":
        """Return a defensive copy with sane numeric bounds."""

        def pct(value: float) -> float:
            try:
                value = float(value)
            except (TypeError, ValueError):
                return 0.0
            return max(0.0, min(100.0, value))

        def count(value: int) -> int:
            try:
                value = int(value)
            except (TypeError, ValueError):
                return 0
            return max(0, value)

        return PubVitals(
            cpu_percent=pct(self.cpu_percent),
            memory_percent=pct(self.memory_percent),
            vram_percent=pct(self.vram_percent),
            disk_percent=pct(self.disk_percent),
            active_rooms=count(self.active_rooms),
            active_guests=count(self.active_guests),
            active_recordings=count(self.active_recordings),
            active_ai_workers=count(self.active_ai_workers),
            degraded_services=count(self.degraded_services),
            failed_services=count(self.failed_services),
            pending_heavy_jobs=count(self.pending_heavy_jobs),
            idle_toolkits=count(self.idle_toolkits),
            is_maintenance_requested=bool(self.is_maintenance_requested),
            is_shutdown_requested=bool(self.is_shutdown_requested),
            recovery_requested=bool(self.recovery_requested),
            emergency_requested=bool(self.emergency_requested),
            notes=tuple(str(note) for note in self.notes if str(note).strip()),
        )

    @classmethod
    def from_mapping(cls, data: Optional[Mapping[str, Any]]) -> "PubVitals":
        """Build vitals from a loose dict without trusting incoming types."""

        if not data:
            return cls()
        allowed = cls.__dataclass_fields__.keys()
        payload: Dict[str, Any] = {key: data[key] for key in allowed if key in data}
        notes = payload.get("notes")
        if isinstance(notes, str):
            payload["notes"] = (notes,)
        elif isinstance(notes, Iterable) and not isinstance(notes, (bytes, bytearray, Mapping)):
            payload["notes"] = tuple(str(item) for item in notes)
        elif notes is not None:
            payload["notes"] = (str(notes),)
        return cls(**payload).normalized()

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["notes"] = list(self.notes)
        return payload


@dataclass(frozen=True)
class PubPolicy:
    """
    Declarative policy published by the Pub Manager.

    This is the sign on the door. Pete, E-Pete, Jeeves, and other spine-owned
    systems adapt their own local behavior to this policy. The Pub Manager does
    not perform their work.
    """

    mode: EstablishmentMode
    risk: RiskLevel
    admit_new_guests: bool = True
    allow_new_rooms: bool = True
    allow_heavy_generation: bool = True
    allow_background_simulation: bool = True
    allow_nonessential_ai: bool = True
    prefer_hibernation: bool = False
    prefer_deferred_jobs: bool = False
    protect_active_recording: bool = True
    ask_jeeves_to_shelve_idle: bool = False
    ask_epete_to_reduce_background_work: bool = False
    ask_pete_to_limit_floor_activity: bool = False
    ai_activity_level: str = "normal"  # normal, reduced, minimal, paused
    guest_admission_reason: str = "normal operations"
    operator_note: str = "The establishment is open."

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["mode"] = self.mode.value
        payload["risk"] = self.risk.value
        return payload


@dataclass(frozen=True)
class PubManagerDecision:
    """A complete declarative Pub Manager decision."""

    mode: EstablishmentMode
    risk: RiskLevel
    vitals: PubVitals
    policy: PubPolicy
    reasons: Tuple[str, ...]
    changed: bool
    decided_at: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mode": self.mode.value,
            "risk": self.risk.value,
            "vitals": self.vitals.to_dict(),
            "policy": self.policy.to_dict(),
            "reasons": list(self.reasons),
            "changed": self.changed,
            "decided_at": self.decided_at,
        }


class PubManager:
    """
    Establishment-wide operations authority.

    The Pub Manager reads PubVitals and publishes PubPolicy. It deliberately
    avoids direct operational side effects. If callers want to emit events,
    update the spine registry, or notify Pete/E-Pete/Jeeves, they should do so
    by consuming the returned decision and routing through the Spine.
    """

    service_name = "pub_manager"
    capability = "establishment_policy"

    def __init__(self, initial_mode: EstablishmentMode = EstablishmentMode.OPEN) -> None:
        self._mode = initial_mode
        self._risk = RiskLevel.NORMAL
        self._last_decision: Optional[PubManagerDecision] = None

    @property
    def mode(self) -> EstablishmentMode:
        return self._mode

    @property
    def risk(self) -> RiskLevel:
        return self._risk

    @property
    def last_decision(self) -> Optional[PubManagerDecision]:
        return self._last_decision

    def evaluate(self, vitals: Optional[PubVitals | Mapping[str, Any]] = None) -> PubManagerDecision:
        """
        Evaluate establishment posture from vitals and return a policy decision.

        No direct subsystem work is performed here. This method is safe to call
        from a status route, periodic spine tick, doctor report, or test.
        """

        clean_vitals = self._coerce_vitals(vitals)
        previous_mode = self._mode
        mode, risk, reasons = self._choose_mode(clean_vitals)
        policy = self._build_policy(mode, risk, clean_vitals, reasons)
        changed = mode != previous_mode or risk != self._risk

        self._mode = mode
        self._risk = risk
        decision = PubManagerDecision(
            mode=mode,
            risk=risk,
            vitals=clean_vitals,
            policy=policy,
            reasons=tuple(reasons),
            changed=changed,
            decided_at=datetime.now(timezone.utc).isoformat(),
        )
        self._last_decision = decision
        return decision

    def current_policy(self) -> PubPolicy:
        """Return the latest policy, evaluating empty/open vitals if needed."""

        if self._last_decision is None:
            return self.evaluate(PubVitals()).policy
        return self._last_decision.policy

    def status(self) -> Dict[str, Any]:
        """Return doctor/dashboard-friendly status."""

        decision = self._last_decision or self.evaluate(PubVitals())
        return {
            "service": self.service_name,
            "registered": True,
            "capability": self.capability,
            "doctrine": "declarative_not_operational",
            "mode": decision.mode.value,
            "risk": decision.risk.value,
            "policy": decision.policy.to_dict(),
            "reasons": list(decision.reasons),
            "last_decision_at": decision.decided_at,
            "boundaries": [
                "does_not_route_packets",
                "does_not_move_avatars",
                "does_not_open_sockets",
                "does_not_load_assets",
                "does_not_clean_folders",
                "does_not_kill_processes",
                "does_not_write_saves_directly",
                "does_not_bypass_spine",
            ],
        }

    def registration_payload(self) -> Dict[str, Any]:
        """Small helper for spine service registration."""

        return {
            "name": self.service_name,
            "capabilities": [self.capability, "establishment_mode", "continuity_policy"],
            "lifecycle": "spine_owned",
            "authority": "declarative_policy_only",
            "status_route": "/api/spine/pub-manager/status",
            "policy_route": "/api/spine/pub-manager/policy",
        }

    def event_payload(self, decision: Optional[PubManagerDecision] = None) -> Dict[str, Any]:
        """
        Build a canonical event payload for callers to emit through the bridge.

        Suggested event name: establishment.mode_changed when changed is true,
        otherwise establishment.policy_evaluated.
        """

        decision = decision or self._last_decision or self.evaluate(PubVitals())
        return {
            "event": "establishment.mode_changed"
            if decision.changed
            else "establishment.policy_evaluated",
            "mode": decision.mode.value,
            "risk": decision.risk.value,
            "policy": decision.policy.to_dict(),
            "reasons": list(decision.reasons),
            "decided_at": decision.decided_at,
        }

    def _coerce_vitals(self, vitals: Optional[PubVitals | Mapping[str, Any]]) -> PubVitals:
        if isinstance(vitals, PubVitals):
            return vitals.normalized()
        if isinstance(vitals, Mapping):
            return PubVitals.from_mapping(vitals)
        return PubVitals()

    def _choose_mode(self, vitals: PubVitals) -> Tuple[EstablishmentMode, RiskLevel, list[str]]:
        reasons: list[str] = []

        if vitals.is_shutdown_requested:
            reasons.append("shutdown requested")
            return EstablishmentMode.HIBERNATED, RiskLevel.PROTECTED, reasons

        if vitals.emergency_requested:
            reasons.append("emergency requested")
            return EstablishmentMode.EMERGENCY, RiskLevel.EMERGENCY, reasons

        if vitals.failed_services > 0:
            reasons.append(f"{vitals.failed_services} failed service(s)")
            return EstablishmentMode.RECOVERY, RiskLevel.RECOVERY, reasons

        if vitals.recovery_requested:
            reasons.append("recovery requested")
            return EstablishmentMode.RECOVERY, RiskLevel.RECOVERY, reasons

        if vitals.is_maintenance_requested:
            reasons.append("maintenance requested")
            return EstablishmentMode.MAINTENANCE, RiskLevel.PROTECTED, reasons

        pressure = max(vitals.cpu_percent, vitals.memory_percent, vitals.vram_percent, vitals.disk_percent)
        if pressure >= 95.0:
            reasons.append(f"critical resource pressure at {pressure:.1f}%")
            return EstablishmentMode.EMERGENCY, RiskLevel.EMERGENCY, reasons

        if pressure >= 88.0 or vitals.degraded_services >= 3:
            if pressure >= 88.0:
                reasons.append(f"severe resource pressure at {pressure:.1f}%")
            if vitals.degraded_services >= 3:
                reasons.append(f"{vitals.degraded_services} degraded service(s)")
            return EstablishmentMode.RECOVERY, RiskLevel.RECOVERY, reasons

        if vitals.active_recordings > 0 and (pressure >= 72.0 or vitals.pending_heavy_jobs > 0):
            reasons.append("active recording protected from competing load")
            if pressure >= 72.0:
                reasons.append(f"recording-time pressure at {pressure:.1f}%")
            if vitals.pending_heavy_jobs > 0:
                reasons.append(f"{vitals.pending_heavy_jobs} pending heavy job(s)")
            return EstablishmentMode.QUIET, RiskLevel.PROTECTED, reasons

        if pressure >= 78.0 or vitals.active_rooms >= 4 or vitals.active_guests >= 8:
            if pressure >= 78.0:
                reasons.append(f"high resource pressure at {pressure:.1f}%")
            if vitals.active_rooms >= 4:
                reasons.append(f"{vitals.active_rooms} active room(s)")
            if vitals.active_guests >= 8:
                reasons.append(f"{vitals.active_guests} active guest(s)")
            return EstablishmentMode.CROWDED, RiskLevel.STRAINED, reasons

        if pressure >= 60.0 or vitals.active_rooms >= 2 or vitals.active_guests >= 4:
            if pressure >= 60.0:
                reasons.append(f"moderate resource pressure at {pressure:.1f}%")
            if vitals.active_rooms >= 2:
                reasons.append(f"{vitals.active_rooms} active room(s)")
            if vitals.active_guests >= 4:
                reasons.append(f"{vitals.active_guests} active guest(s)")
            return EstablishmentMode.BUSY, RiskLevel.WATCH, reasons

        if vitals.idle_toolkits > 0 and vitals.active_rooms == 0 and vitals.active_guests == 0:
            reasons.append(f"{vitals.idle_toolkits} idle toolkit(s) ready for shelving")
            return EstablishmentMode.LATE_NIGHT, RiskLevel.NORMAL, reasons

        reasons.append("normal operations")
        return EstablishmentMode.OPEN, RiskLevel.NORMAL, reasons

    def _build_policy(
        self,
        mode: EstablishmentMode,
        risk: RiskLevel,
        vitals: PubVitals,
        reasons: Iterable[str],
    ) -> PubPolicy:
        reason_text = "; ".join(reasons) or "normal operations"

        if mode == EstablishmentMode.HIBERNATED:
            return PubPolicy(
                mode=mode,
                risk=risk,
                admit_new_guests=False,
                allow_new_rooms=False,
                allow_heavy_generation=False,
                allow_background_simulation=False,
                allow_nonessential_ai=False,
                prefer_hibernation=True,
                prefer_deferred_jobs=True,
                protect_active_recording=True,
                ask_jeeves_to_shelve_idle=True,
                ask_epete_to_reduce_background_work=True,
                ask_pete_to_limit_floor_activity=True,
                ai_activity_level="paused",
                guest_admission_reason="establishment is hibernated",
                operator_note="The establishment is hibernated. Preserve bookmarks and await wake instruction.",
            )

        if mode == EstablishmentMode.EMERGENCY:
            return PubPolicy(
                mode=mode,
                risk=risk,
                admit_new_guests=False,
                allow_new_rooms=False,
                allow_heavy_generation=False,
                allow_background_simulation=False,
                allow_nonessential_ai=False,
                prefer_hibernation=True,
                prefer_deferred_jobs=True,
                protect_active_recording=True,
                ask_jeeves_to_shelve_idle=True,
                ask_epete_to_reduce_background_work=True,
                ask_pete_to_limit_floor_activity=True,
                ai_activity_level="minimal",
                guest_admission_reason="emergency posture active",
                operator_note=f"Emergency posture. Preserve continuity and reduce nonessential work: {reason_text}.",
            )

        if mode == EstablishmentMode.RECOVERY:
            return PubPolicy(
                mode=mode,
                risk=risk,
                admit_new_guests=False,
                allow_new_rooms=False,
                allow_heavy_generation=False,
                allow_background_simulation=False,
                allow_nonessential_ai=False,
                prefer_hibernation=True,
                prefer_deferred_jobs=True,
                protect_active_recording=True,
                ask_jeeves_to_shelve_idle=True,
                ask_epete_to_reduce_background_work=True,
                ask_pete_to_limit_floor_activity=True,
                ai_activity_level="minimal",
                guest_admission_reason="recovery mode active",
                operator_note=f"Recovery mode. Keep current safe operations only: {reason_text}.",
            )

        if mode == EstablishmentMode.MAINTENANCE:
            return PubPolicy(
                mode=mode,
                risk=risk,
                admit_new_guests=False,
                allow_new_rooms=False,
                allow_heavy_generation=False,
                allow_background_simulation=False,
                allow_nonessential_ai=False,
                prefer_hibernation=True,
                prefer_deferred_jobs=True,
                protect_active_recording=True,
                ask_jeeves_to_shelve_idle=True,
                ask_epete_to_reduce_background_work=True,
                ask_pete_to_limit_floor_activity=True,
                ai_activity_level="paused",
                guest_admission_reason="maintenance mode active",
                operator_note="Maintenance mode. New activity is paused while the establishment is serviced.",
            )

        if mode == EstablishmentMode.QUIET:
            return PubPolicy(
                mode=mode,
                risk=risk,
                admit_new_guests=False,
                allow_new_rooms=False,
                allow_heavy_generation=False,
                allow_background_simulation=False,
                allow_nonessential_ai=False,
                prefer_hibernation=True,
                prefer_deferred_jobs=True,
                protect_active_recording=True,
                ask_jeeves_to_shelve_idle=vitals.idle_toolkits > 0,
                ask_epete_to_reduce_background_work=True,
                ask_pete_to_limit_floor_activity=True,
                ai_activity_level="reduced",
                guest_admission_reason="quiet mode protects active work",
                operator_note=f"Quiet mode. Protect the active floor and defer extras: {reason_text}.",
            )

        if mode == EstablishmentMode.CROWDED:
            return PubPolicy(
                mode=mode,
                risk=risk,
                admit_new_guests=False,
                allow_new_rooms=False,
                allow_heavy_generation=False,
                allow_background_simulation=True,
                allow_nonessential_ai=False,
                prefer_hibernation=True,
                prefer_deferred_jobs=True,
                protect_active_recording=True,
                ask_jeeves_to_shelve_idle=vitals.idle_toolkits > 0,
                ask_epete_to_reduce_background_work=True,
                ask_pete_to_limit_floor_activity=True,
                ai_activity_level="reduced",
                guest_admission_reason="establishment is crowded",
                operator_note=f"Crowded mode. Hold new heavy load and keep current rooms stable: {reason_text}.",
            )

        if mode == EstablishmentMode.BUSY:
            return PubPolicy(
                mode=mode,
                risk=risk,
                admit_new_guests=True,
                allow_new_rooms=True,
                allow_heavy_generation=False,
                allow_background_simulation=True,
                allow_nonessential_ai=True,
                prefer_hibernation=vitals.idle_toolkits > 0,
                prefer_deferred_jobs=True,
                protect_active_recording=True,
                ask_jeeves_to_shelve_idle=vitals.idle_toolkits > 0,
                ask_epete_to_reduce_background_work=False,
                ask_pete_to_limit_floor_activity=False,
                ai_activity_level="normal",
                guest_admission_reason="busy but available",
                operator_note=f"Busy mode. Admit carefully and defer heavy nonessential work: {reason_text}.",
            )

        if mode == EstablishmentMode.LATE_NIGHT:
            return PubPolicy(
                mode=mode,
                risk=risk,
                admit_new_guests=True,
                allow_new_rooms=True,
                allow_heavy_generation=True,
                allow_background_simulation=True,
                allow_nonessential_ai=True,
                prefer_hibernation=True,
                prefer_deferred_jobs=False,
                protect_active_recording=True,
                ask_jeeves_to_shelve_idle=True,
                ask_epete_to_reduce_background_work=False,
                ask_pete_to_limit_floor_activity=False,
                ai_activity_level="normal",
                guest_admission_reason="quiet establishment, available",
                operator_note=f"Late night mode. Good time for Jeeves to put idle things away: {reason_text}.",
            )

        return PubPolicy(
            mode=EstablishmentMode.OPEN,
            risk=RiskLevel.NORMAL,
            admit_new_guests=True,
            allow_new_rooms=True,
            allow_heavy_generation=True,
            allow_background_simulation=True,
            allow_nonessential_ai=True,
            prefer_hibernation=False,
            prefer_deferred_jobs=False,
            protect_active_recording=True,
            ask_jeeves_to_shelve_idle=False,
            ask_epete_to_reduce_background_work=False,
            ask_pete_to_limit_floor_activity=False,
            ai_activity_level="normal",
            guest_admission_reason="normal operations",
            operator_note="The establishment is open.",
        )


def build_pub_manager_status(vitals: Optional[PubVitals | Mapping[str, Any]] = None) -> Dict[str, Any]:
    """Convenience helper for simple route integration."""

    manager = PubManager()
    decision = manager.evaluate(vitals)
    return decision.to_dict()


# Optional singleton for apps that prefer importing a spine-owned service object.
pub_manager = PubManager()
