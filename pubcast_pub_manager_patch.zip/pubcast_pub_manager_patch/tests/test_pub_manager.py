from runtime.pub_manager import EstablishmentMode, PubManager, PubVitals, RiskLevel


def test_pub_manager_open_by_default():
    manager = PubManager()
    decision = manager.evaluate(PubVitals())
    assert decision.mode == EstablishmentMode.OPEN
    assert decision.risk == RiskLevel.NORMAL
    assert decision.policy.admit_new_guests is True
    assert decision.policy.allow_heavy_generation is True


def test_pub_manager_quiet_protects_active_recording():
    manager = PubManager()
    decision = manager.evaluate(
        PubVitals(
            cpu_percent=74,
            active_recordings=1,
            pending_heavy_jobs=2,
            idle_toolkits=3,
        )
    )
    assert decision.mode == EstablishmentMode.QUIET
    assert decision.policy.admit_new_guests is False
    assert decision.policy.allow_heavy_generation is False
    assert decision.policy.ask_jeeves_to_shelve_idle is True
    assert decision.policy.ask_epete_to_reduce_background_work is True
    assert decision.policy.ask_pete_to_limit_floor_activity is True


def test_pub_manager_crowded_limits_new_load():
    manager = PubManager()
    decision = manager.evaluate(PubVitals(memory_percent=82, active_rooms=4, active_guests=8))
    assert decision.mode == EstablishmentMode.CROWDED
    assert decision.risk == RiskLevel.STRAINED
    assert decision.policy.admit_new_guests is False
    assert decision.policy.prefer_deferred_jobs is True


def test_pub_manager_recovery_on_failed_service():
    manager = PubManager()
    decision = manager.evaluate(PubVitals(failed_services=1))
    assert decision.mode == EstablishmentMode.RECOVERY
    assert decision.policy.admit_new_guests is False
    assert decision.policy.allow_background_simulation is False
    assert decision.policy.ai_activity_level == "minimal"


def test_pub_manager_emergency_on_critical_pressure():
    manager = PubManager()
    decision = manager.evaluate(PubVitals(cpu_percent=96))
    assert decision.mode == EstablishmentMode.EMERGENCY
    assert decision.risk == RiskLevel.EMERGENCY
    assert decision.policy.allow_new_rooms is False
    assert decision.policy.prefer_hibernation is True


def test_pub_manager_late_night_asks_jeeves_to_shelve_idle_tools():
    manager = PubManager()
    decision = manager.evaluate(PubVitals(idle_toolkits=5))
    assert decision.mode == EstablishmentMode.LATE_NIGHT
    assert decision.policy.ask_jeeves_to_shelve_idle is True
    assert decision.policy.admit_new_guests is True


def test_pub_manager_status_declares_boundaries():
    manager = PubManager()
    status = manager.status()
    assert status["doctrine"] == "declarative_not_operational"
    assert "does_not_open_sockets" in status["boundaries"]
    assert "does_not_clean_folders" in status["boundaries"]
    assert status["policy"]["mode"] == "open"


def test_pub_manager_registration_payload():
    manager = PubManager()
    payload = manager.registration_payload()
    assert payload["name"] == "pub_manager"
    assert "establishment_policy" in payload["capabilities"]
    assert payload["authority"] == "declarative_policy_only"
