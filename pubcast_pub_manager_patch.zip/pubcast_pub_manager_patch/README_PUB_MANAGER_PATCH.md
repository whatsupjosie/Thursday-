# PubCast Pub Manager Patch

Adds a lean establishment-wide operations authority:

- `runtime/pub_manager.py`
- `tests/test_pub_manager.py`

Doctrine:

> The Pub Manager is declarative, not operational.

It reads vitals, chooses an establishment mode, publishes policy, and reports status. It does not execute subsystem work directly.

Suggested routes:

- `/api/spine/pub-manager/status`
- `/api/spine/pub-manager/policy`

Suggested bridge events:

- `establishment.policy_evaluated`
- `establishment.mode_changed`

Suggested spine registration:

```python
from runtime.pub_manager import pub_manager
spine.register_service(pub_manager.registration_payload())
```

Suggested status route:

```python
@app.get("/api/spine/pub-manager/status")
def pub_manager_status():
    vitals = collect_pub_vitals_somewhere_safe()
    decision = pub_manager.evaluate(vitals)
    return decision.to_dict()
```

The route should collect vitals from existing spine/doctor/resource observers. The Pub Manager should not collect by opening sockets, touching engines, or cleaning files directly.
