# PubCast Behavior Animation System

Drop-in behavior layer for the PubCast avatar animation preset library.

This package does **not** replace the preset files. It adds the missing intelligence layer above them:

- behavioral memory
- animation suppression
- layer priority
- conflict resolution
- seated/standing context
- intent-driven selection

Start with `docs/BEHAVIOR_ANIMATION_ENGINE_HANDOFF.md`.
