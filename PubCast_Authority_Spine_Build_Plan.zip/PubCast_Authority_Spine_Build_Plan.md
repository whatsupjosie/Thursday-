# PubCast Authority Spine — Implementation / Build Handoff

## Purpose

This handoff turns the current spine work into the next concrete engineering build plan.

The uploaded architecture review shows that PubCast already has real runtime systems: mic processing, audio routing, device selection, mocap, smoothing, callback dispatch, and WebSocket hooks. The problem is no longer “can the systems exist?” The problem is “who owns truth, who gets authority, and how do systems negotiate control without drifting apart?”

The next build target is therefore the **Authority Spine**: a governed runtime layer that coordinates avatars, motion, audio, AI, events, sessions, and engines.

---

## Current Completed Spine Layers

These are assumed already implemented or patch-ready:

1. Runtime spine foundation
2. Contracts / lifecycle / capabilities
3. Governance / boot order
4. Avatar spine integration
5. World / room spine integration
6. Continuous spine layer including event bridge, motion state, AI router, session snapshots, doctor aggregation, and legacy scan

If any of those are not yet applied, apply and verify them before continuing.

---

# Strategic Diagnosis

PubCast is entering the **authority architecture phase**.

The project now has multiple real systems that can affect the same performer or session:

- user mocap
- AI performer behavior
- scripted animation
- idle animation
- mic state
- cough suppression
- room/world movement
- WebSocket events
- session persistence
- multiple engines
- browser-side runtime behavior
- server-side orchestration

Without a formal authority layer, each system can become its own little government. That creates drift, stuck states, hidden overrides, duplicated state, and impossible debugging.

The next major principle is:

> No subsystem controls a performer, avatar, audio channel, room, or engine directly without going through the spine authority model.

---

# High-Level Build Order

The safest build order is:

1. Event Contract Layer
2. Performer Authority Layer
3. Motion / Mocap Calibration Layer
4. Audio Authority Layer
5. Session Persistence Expansion
6. Runtime Supervisor / Watchdog
7. Doctor Dashboard Unification
8. Legacy Containment and Canonical Path Enforcement

This order matters because later systems need earlier systems to report state and arbitrate ownership.

---

# Phase 1 — Event Contract Layer

## What This Is

A formal schema for all spine events.

Right now WebSocket payloads and runtime messages risk becoming ad hoc. The event contract layer defines names, versions, payload fields, timestamps, source systems, target systems, and validation.

## Why It Comes First

Everything else needs a common language. Performer authority, mic authority, motion, AI routing, and session persistence all depend on consistent events.

## Files to Add

```text
runtime/event_contracts.py
runtime/event_types.py
runtime/event_validator.py
tests/test_spine_event_contracts.py
```

## Core Event Fields

Each event should include:

```python
{
    "event_id": "uuid",
    "event_type": "avatar.moved",
    "version": 1,
    "timestamp": "iso8601",
    "source": "world_service",
    "target": "spine",
    "session_id": "default",
    "payload": {},
}
```

## Canonical Event Families

```text
spine.*
avatar.*
world.*
room.*
motion.*
performer.*
ai.*
audio.*
mic.*
session.*
engine.*
doctor.*
legacy.*
```

## First Events to Define

```text
avatar.registered
avatar.asset.validated
avatar.asset.failed
avatar.moved
world.room.registered
world.avatar.entered_room
world.avatar.left_room
motion.state.changed
performer.authority.claimed
performer.authority.released
ai.intent.requested
ai.intent.approved
ai.intent.denied
audio.input.claimed
mic.cough.started
mic.cough.expired
session.snapshot.saved
engine.capability.reported
```

## Implementation Steps

1. Create event dataclass or Pydantic model.
2. Add strict validation function.
3. Update event bus so emitted events are normalized.
4. Reject or quarantine malformed events.
5. Add `/api/spine/events/contracts`.
6. Add tests for valid and invalid events.

## Done When

- All spine-emitted events share a consistent schema.
- Movement emits a validated event.
- Avatar registration emits a validated event.
- Bad event payloads fail honestly.

---

# Phase 2 — Performer Authority Layer

## What This Is

The central ownership model for who is allowed to control each performer/avatar/body part/state.

This is the missing layer between mocap, AI, scripts, animation, physics, and room/world systems.

## Why It Matters

Mocap produces motion. AI produces intent. Scripts produce animation. Idle systems produce background behavior. Without arbitration, they fight.

## Files to Add

```text
runtime/performer_authority.py
runtime/authority_claims.py
runtime/authority_priority.py
tests/test_performer_authority.py
```

## Authority Concepts

### Authority Source

```text
human_mocap
ai_persona
ai_engine
scripted_animation
idle_system
physics
emergency_override
system_fallback
```

### Body Channels

```text
full_body
root
hips
spine
head
face
left_arm
right_arm
left_hand
right_hand
left_leg
right_leg
feet
gaze
voice
room_position
camera_interest
```

### Priority Order

Recommended default:

```text
1. emergency_override
2. human_mocap
3. scripted_animation
4. ai_engine
5. ai_persona
6. physics correction
7. idle_system
8. system_fallback
```

This order can be adjusted later through the spine governor.

## Main API

```python
authority.claim(performer_id, channel, source, priority, ttl_ms, reason)
authority.release(claim_id)
authority.resolve(performer_id, channel)
authority.status(performer_id)
authority.expire_stale_claims()
```

## Important Rule

Every claim needs a TTL unless it is explicitly persistent and governed.

This prevents stuck states.

## Example

```text
User mocap owns torso and hips.
AI persona owns face and gaze.
Script owns right_arm for a wave.
Physics owns feet correction.
Idle system owns only unclaimed channels.
```

## Implementation Steps

1. Create authority claim model.
2. Add performer authority registry.
3. Add expiration handling.
4. Add priority resolution.
5. Register service with spine.
6. Add `/api/spine/performers/authority`.
7. Connect motion service to authority claims.
8. Connect AI router to authority requests, not direct control.
9. Add tests for conflict resolution.

## Done When

- Two systems can request the same body channel and the correct winner is selected.
- Expired claims are cleaned up.
- AI cannot directly own a channel without a registered claim.
- Idle only controls unclaimed channels.

---

# Phase 3 — Motion / Mocap Calibration Layer

## What This Is

A calibration layer between raw mocap and avatar motion.

The review says the mocap pipeline is solid, but it lacks calibration, neutral pose capture, floor alignment, limb normalization, and constraint solving.

## Files to Add

```text
runtime/motion_calibration.py
runtime/skeleton_constraints.py
runtime/motion_retarget_profile.py
tests/test_motion_calibration.py
```

## Calibration Needs

```text
neutral pose capture
T-pose or A-pose capture
floor plane solve
pelvis offset solve
limb-length normalization
avatar scale compensation
stride normalization
confidence baseline
```

## Constraint Needs

```text
foot planting
knee direction limits
elbow direction limits
spine stabilization
clavicle solve
head/neck limits
hand grounding
occlusion recovery
```

## Implementation Steps

1. Add calibration profile object.
2. Store per-performer calibration in session state.
3. Add neutral pose capture command.
4. Add floor solve placeholder that records/calculates baseline.
5. Add retarget profile for avatar proportions.
6. Feed calibrated motion into performer authority, not directly into avatar renderer.
7. Add `/api/spine/motion/calibration/status`.
8. Add tests for missing calibration, stored calibration, and fallback behavior.

## Done When

- A performer can have a calibration profile.
- Motion state reports calibrated/unconfigured/degraded.
- Avatar retargeting has a place to use scale and floor offsets.
- Missing calibration fails softly, not silently.

---

# Phase 4 — Audio Authority Layer

## What This Is

A canonical owner for mic state, device streams, cough suppression, monitor mode, and audio routing.

The review shows mic state is currently split across JS profiles, JS processor, Python routes, localStorage, WebSocket state, and server dictionaries.

## Files to Add

```text
runtime/audio_authority.py
runtime/mic_state_authority.py
runtime/audio_graph_registry.py
tests/test_audio_authority.py
```

## What It Owns

```text
mic muted/unmuted
cough suppression
device selection
stream ownership
monitor mode
profile selection
gain/compressor/filter state
audio graph lifecycle
stale state expiry
```

## Cough Suppression Fix

Cough suppression must expire automatically.

Recommended behavior:

```text
cough active: true
refresh heartbeat required every 1 second
expire after 3 seconds without refresh
emit mic.cough.expired
```

## Audio Graph Fix

Create graph registry that tracks:

```text
node id
node type
owner
connected inputs
connected outputs
created_at
last_seen
teardown status
```

## Monitor Safety

Monitor mode must include:

```text
warning flag
limiter state
emergency mute path
monitor bus isolation
```

## Implementation Steps

1. Create canonical MicState object.
2. Move server-side cough state behind authority API.
3. Add stale cleanup method.
4. Add audio graph registry model.
5. Add `/api/spine/audio/status`.
6. Add `/api/spine/mic/status`.
7. Add tests for cough expiry and mute desync prevention.
8. Update existing mic routes gradually to delegate to authority.

## Done When

- There is one reported mic truth.
- Cough cannot get stuck forever.
- Audio graph can report active nodes.
- Existing browser code can still function while the spine becomes authoritative.

---

# Phase 5 — Session Persistence Expansion

## What This Is

The spine should save and restore important runtime state.

Not everything needs full implementation immediately. Start with structured snapshots.

## Files to Add or Expand

```text
runtime/session_persistence.py
runtime/session_snapshot.py
tests/test_session_persistence.py
```

## Snapshot Contents

```text
session id
registered systems
boot order
avatar identities
avatar rooms
performer authority claims
motion states
calibration profiles
audio/mic state
AI mode/state
engine capabilities
recent spine events
legacy warnings
credits metadata
```

## Implementation Steps

1. Define snapshot schema.
2. Add save-to-json function.
3. Add load-from-json skeleton with validation.
4. Expose `/api/spine/session/snapshot`.
5. Do not auto-restore dangerous runtime state yet.
6. Add tests for snapshot round-trip.

## Done When

- The spine can produce a clear session snapshot.
- Snapshot is versioned.
- Missing fields are handled safely.
- Restore is explicit, not automatic magic.

---

# Phase 6 — Runtime Supervisor / Watchdog

## What This Is

A system that watches for stale threads, dead callbacks, stuck claims, stale mic/cough state, stale mocap frames, and degraded services.

## Files to Add

```text
runtime/supervisor.py
runtime/watchdog.py
tests/test_runtime_supervisor.py
```

## What It Watches

```text
event bridge heartbeat
mocap frame freshness
mic heartbeat
cough suppression expiry
AI router availability
engine capability heartbeat
performer authority stale claims
session persistence errors
audio graph leaks
```

## Implementation Steps

1. Add supervisor service.
2. Register health checks from each subsystem.
3. Add heartbeat timestamps.
4. Add degraded/failed states.
5. Add `/api/spine/supervisor/status`.
6. Add tests for stale service detection.

## Done When

- Stale systems are reported.
- Stuck authority claims expire.
- Stale cough suppression expires.
- Doctor dashboard can show degraded systems.

---

# Phase 7 — Doctor Dashboard Unification

## What This Is

The final human-readable status layer that pulls all spine reports together.

## Should Show

```text
spine boot status
registered services
boot order
system lifecycle
contracts
capabilities
avatar truth
world truth
event bridge status
performer authority status
motion/calibration status
AI router status
audio/mic status
session persistence status
supervisor warnings
legacy startup warnings
missing assets
failed imports
```

## Files to Add or Expand

```text
doctor/spine_report.py
static/doctor_spine.html
tests/test_spine_doctor_report.py
```

## Implementation Steps

1. Create aggregated report builder.
2. Add `/api/doctor/spine`.
3. Optionally add static readable HTML dashboard.
4. Keep data JSON-first so UI can improve later.

## Done When

- One endpoint can tell what is alive, missing, degraded, or pending.
- Report is useful to the user without reading logs.

---

# Phase 8 — Legacy Containment

## What This Is

Prevent old startup paths from pretending to be canonical.

Do not delete old files. Label and route them.

## Categories

```text
canonical
registered
legacy
experimental
pending
broken
rubbish_bin
```

## Implementation Steps

1. Expand legacy scan.
2. Detect duplicate app entry points.
3. Detect duplicate websocket routes.
4. Detect duplicate avatar loaders.
5. Detect sprite fallbacks.
6. Produce report, not destructive edits.
7. Add warnings to doctor dashboard.

## Done When

- The project clearly knows which startup path is canonical.
- Old systems are not accidentally treated as production truth.

---

# Two-AI / Multi-Engine Rules

## Required Separation

PubCast must not collapse the two-AI architecture into one generic assistant.

### Persona AI

Owns:

```text
speech
character behavior
guest interaction
performance tone
waiting room/dressing room social logic
```

May request:

```text
emotes
gaze
small gestures
lines
room interaction suggestions
```

May not directly control:

```text
engine resource allocation
render mode
camera system
file operations
runtime authority claims without approval
```

### Engine AI

Owns advice/requests for:

```text
resource routing
render mode suggestions
system degradation decisions
scene operations
engine capability matching
camera/lighting strategy
```

May not directly control:

```text
avatar body channels
user mocap override
persona behavior
performer identity
```

### Spine Governor

Owns final approval for:

```text
authority claims
system activation
engine switching
resource degradation
AI control requests
session-level mutations
```

---

# Immediate Next Patch Recommendation

The next patch should implement **Phase 1 + the foundation of Phase 2**.

That means:

```text
Patch Name:
PubCast-Wednesday-Authority-Spine-Events-Performer-Patch.zip
```

## Include

```text
runtime/event_contracts.py
runtime/event_validator.py
runtime/performer_authority.py
runtime/authority_claims.py
```

## Add Routes

```text
/api/spine/events/contracts
/api/spine/performers/authority
/api/spine/performers/authority/status
```

## Add Tests

```text
tests/test_spine_event_contracts.py
tests/test_performer_authority.py
```

## Validate

```text
compile all new files
main.py imports
spine attaches
valid event passes
invalid event fails
human mocap beats idle
script beats AI persona for temporary gesture
expired claim releases
AI cannot bypass authority model
```

---

# Implementation Philosophy

Do not rewrite everything.

Do not move the whole app.

Do not force every existing route to use the spine immediately.

Instead:

1. Add authority services.
2. Expose status endpoints.
3. Add tests.
4. Start routing new behavior through spine.
5. Gradually adapt old systems.
6. Let doctor/preflight reveal what still bypasses authority.

This keeps the app alive while the skeleton hardens.

---

# Continuous Job Instruction

Use this for the next implementation job:

```text
Continue building PubCast’s Authority Spine.

Do not create isolated features. Every change must register with or report to the spine.

First implement formal event contracts, then performer authority arbitration. The event layer must define event schema, canonical event names, event versions, validation, and status reporting. The performer authority layer must define ownership claims, priority resolution, TTL expiry, body/channel masks, and conflict resolution between human mocap, AI persona, AI engine, scripted animation, idle behavior, physics correction, and emergency override.

Do not let either AI directly control avatar body channels, room state, engine state, or session state without a spine-approved authority request.

Do not delete old systems. Do not replace Manny or Sheila with sprites. Do not fake success with placeholders. Keep changes non-destructive and testable.

Add or update routes for event contracts and performer authority status. Add focused tests proving valid events pass, invalid events fail, authority priority works, stale claims expire, and AI cannot bypass the authority model.

After that, continue into motion calibration, audio/mic authority, session persistence expansion, runtime supervisor/watchdog, doctor dashboard unification, and legacy containment.

At the end, report changed files, tests run, what now works, what remains pending, and any caution before applying the patch.
```

---

# Bottom Line

The spine foundation gives PubCast a backbone.

The next authority layers give it a nervous system.

The next highest-value move is:

> Formal event contracts + performer authority arbitration.

That is the gateway to making mocap, AI, avatar motion, audio state, room movement, and multiple engines cooperate instead of competing.
