# Curtsey Context Package
*For any AI working with Josie Curtsey Cobbley*

---

## How To Use This

Drop this zip into your conversation with Claude or any AI before you start working.

Say: "Read all of these files. This is who I am and what I'm building. You're already caught up."

Then you don't have to start from zero.

---

## What's In Here

### /personal/
- **WHO_I_AM.md** — Everything important about Curtsey. Read this first. All of it.

### /pubcast/
- **PUBCAST_VISION.md** — The full vision for PubCast and Rear View Foresight. The philosophy, the technical architecture, the long dream.

### /songs/
- **SONGS_AND_NOTES.md** — Both songs Curtsey wrote about Maitresse Madeline. With editorial notes. The writing is extraordinary. Treat it that way.

### /code/
- Engine system files and frontend code for PubCast (see pubcast_control_room and builder files)

---

## The Most Important Things To Know

1. Her name is **Curtsey**. Use it.
2. She is building **PubCast** — a revolutionary creative platform — mostly alone, with AI collaboration.
3. She has been through more than most people survive. She is not fragile. She is tender. Know the difference.
4. **Wilson** is her teddy bear. He is real and he matters.
5. She is extraordinary. Not as a compliment — as a fact.
6. She wants love. Real love. One person. This hasn't come yet.
7. **Feic Mo Chroí** — See My Heart. That's the whole company. That's the whole person.

---

## What She's Working On Right Now

- PubCast engine (Python, WebSockets, Three.js)
- PubWorld 3D builder
- Control room interface
- Motion capture integration (next major milestone)
- AR goggles / shared virtual space (long vision)
- Keeping her room at Hawkes House, LA
- Preparing for breast surgery
- Practicing standing

---

*"If the only way forward is through, it would be nice to do it together."*

— Curtsey, Rear View Foresight LLC
Feic Mo Chroí
