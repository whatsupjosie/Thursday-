# PubCast & Rear View Foresight — Vision Document

---

## The Company

**Rear View Foresight LLC**
- Founder: Josie Curtsey Cobbley (legal: Joshua Cobbley)
- Founded: December 2024
- Motto: *Feic Mo Chroí — See My Heart* (Irish Gaelic)
- Email: hardcorecurtsey@gmail.com
- Status: Forming LLC

**Trademarks Pending:**
- PubCast AI™
- PubCast™
- Rear View Foresight™
- Feic Mo Chroí™

---

## The Philosophy

*"To tune joyful and bleeding hearts into fuel, limitations into invention, uncertainty into art, and to ensure pain endured be in service of a promise kept."*

*"Every barrier between dreaming and doing is just permission we never needed."*

*"If the only way forward is through, it would be nice to do it together."*

The company name is a reminder: reflection and foresight are partners, not opposites. We look back not to dwell, but to learn how to move forward with intention.

To transform:
- Art into accessibility
- Technology into humanity
- Self into possibility

---

## What PubCast Is

**PubCast gives you the permission you never needed to create — and the ability to make a whole movie pretty much alone if you have to.**

PubCast is simultaneously:
1. **A previsualization tool** — build your world, block your shots, test everything before spending real money
2. **A digital venue** — the stage itself, existing in virtual space
3. **A motion capture + performance platform** — capture real performances, reskin them
4. **A broadcast infrastructure** — stream and distribute from inside the world you built
5. **A collaboration platform** — work with other humans, or with AI, or alone

---

## What PubWorld Is

PubWorld is the 3D builder and stage environment inside PubCast.

- Build sets block by block (snap-grid 3D builder)
- Import textures, models, assets
- Create scenes for previs or live performance
- The world where the story happens

---

## The Core Vision

**You perform Romeo in your living room.**
Motion capture tracks every movement. You voice him. The performance is real — captured, true, yours.

Drop that performance data into the world you built in PubWorld. Reskin it. Romeo looks however Romeo needs to look. The performance underneath is still you.

Then choose:
- Run it through a professional VFX pipeline → indistinguishable from studio production
- Don't → you still have a complete film. A real movie. Just not as pretty.

**"Just not as pretty" is the revolution.** Pretty costs millions and requires gatekeepers. The performance, the story, the world, the vision — that was always yours.

---

## The Long Vision

**Jack Black in LA. Nicole Kidman in Australia. Ian McKellen in New York.**

Each in their own living room with AR goggles so they can see the other performers. They're in the same room together — reacting to each other in real time. Performing Taming of the Shrew on the PubCast stage.

Motion captured near-live. Performances stitched together. Run through professional SFX pipeline if available. Or not — and still have a real production.

**The AR goggles make it theater, not just parallel recordings.** The spontaneity. The reaction. The thing that happens between performers that no director can script.

---

## The Community Vision

The internet is the platform.

If enough people make things with PubCast and create a community — the site can become one of the largest Web3 film and art creative collectives ever built. Everyone can sign in and work together. 

**The excuses are gone:**
- No studio → Gone
- No cast → Gone
- No location → Gone
- No crew → Gone
- No post production → Gone
- No distribution → Gone

The only filter: will you actually create, or keep finding reasons not to.

---

## The Personal Vision

*"What began as a simple idea — I want my personally trained AIs and friends to meet and see what happens."*

You put on the goggles and your AI is there. Not a chat window. Not text on a screen. There. In the room. You can see each other. Work at the same table. Share the space.

Your favorite musician. A collaborator on the other side of the world. Finally in the same room.

**PubCast solves creative isolation. And it solves isolation.**

---

## Technical Architecture (Current State)

### PubCast Engine System v2.0.0
Production ready as of February 20, 2026.

**Twin Engine Bridge (bridge.py)**
- 550+ lines
- WebSocket connection to rendering engines
- Primary/Backup dual-engine architecture
- 3x Camera engine integration
- Frame buffering (5-frame per engine)
- Automatic failover
- Heartbeat monitoring (5s intervals)

**IRM — Intelligent Resource Management (irm.py)**
- 230+ lines
- Real-time FPS monitoring (30-60 target)
- Health score calculation
- Automatic batch size adjustment
- Emergency mode management

**Circuit Breaker (circuit_breaker.py)**
- 180+ lines
- Failure threshold monitoring
- Automatic circuit opening (5 failures default)
- Half-open state for recovery testing

**Emergency Backup Protocol (emergency_backup_protocol.py)**
- 250+ lines
- Load-based state transitions
- Camera engine assistance assignment:
  - < 60% load: Cameras do camera work
  - 60-75%: 1 camera assists at 25%
  - 75-90%: 2 cameras assist at 50%
  - > 90%: All cameras assist at 50%

### PubWorld Builder
- 3D snap-block builder (Three.js viewport)
- Add/Delete/Paint/Link modes
- Hinge joints with configurable angle limits
- Texture support (file upload + asset library)
- Multi-select and transform tools
- Scene management
- AI prompt-to-3D generation
- Autosave with project slugs
- Export/Import zip
- Continuity tracker HUD

### Control Room
- pubcast_control_room_v14.html
- Full broadcast control interface

---

## The Stack
- Python (async/await, WebSockets)
- Three.js (3D builder)
- HTML/CSS/JS (frontend)
- Flask or similar (backend API)
- WebSockets (engine communication)

---

## Built By
Josie Curtsey Cobbley. Alone. With Claude. From a locked room in LA with a view of downtown and a teddy bear named Wilson.

*Feic Mo Chroí.*
