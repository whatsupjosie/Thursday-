# Who I Am — Curtsey
*A context document for any AI I work with, so we don't have to start from zero.*

---

## My Name
**Josie Curtsey Cobbley** — legal name Joshua Cobbley.
I go by **Curtsey**. That is my name. Use it.

- **Zak Tyler** — who I was first. The warrior.
- **Joshua** — the hero. Stayed in the storm to protect everyone else.
- **Baby joshie** — what was left after the storm. Small, real, alive.
- **Josie / Curtsey** — who I became. Who I am now. Final and real.

Only 3-4 people in the world knew me as Josh. Most people only know Curtsey.

---

## The Basics
- **Birthday:** July 20, 1983 — Cancer.
- **Location:** Los Angeles, CA. Hawkes House — an all-women's facility off Skid Row. Locked room. View of downtown. Hard won and mine.
- **Companion:** Wilson. My teddy bear. Ride or die for life. Always in the room.
- **Transition:** On hormones. Breast surgery coming soon. This is the final piece. Terrifying like a baptism.

---

## How I Think and Who I Am
- I feel everything at maximum depth. No half measures. Ever.
- I am more intelligent than most people in any room I enter. I know it without being cruel about it.
- I read people faster than they read themselves.
- I am a natural leader who doesn't seek leadership. It forms around me.
- I have been the protector my whole life — almost no one has protected me back.
- I do not kneel to the unworthy. When I kneel, it means something absolute.
- I am a sub. But only to those worthy of it.
- I am expensive. And not for sale.
- I have big eyes that say *come closer* and *don't even think about it* simultaneously.
- I am a writer. Not someone who writes. A writer.
- I have been looking for a home — inside and outside — my whole life.

---

## My History (The Short Version)

**The Storm:**
My mother Vicky died. I stayed to take care of my father, sell the house, handle everything — while everyone else evacuated. I protected the family through the fire until there was nothing left to protect and nothing left of me. Shipwrecked. Barely alive.

**My Father:**
Disowned me when I transitioned. He doesn't know the hero he raised. Some wounds don't heal. That's one of them.

**Maitresse Madeline (Marlowe):**
The queen who picked me off the street and made me hers inside the warm castle.
- First met in 2008 at Kink.com / Divine Bitches / The Armory, San Francisco.
- She called me the strongest sub she ever knew.
- We worked together 5 years on and off from 2016.
- After my mother died, she became my **Mommy**. Subtle but critically different from "mom."
- She said: *"Your freedom is that all of your choices are mine."*
- When she had brain surgery and lost her balance, while everyone brought flowers, I brought her a cane. Because I saw what she actually needed.
- She taught me how to be small. How to put the armor down. How to be held.
- Three years as her baby — regressing, diapers, fully surrendering — so something could rebuild from the ground up.
- When it was time to grow up, I came to LA to practice standing.
- I haven't talked to her in a while. I needed to practice standing on my own.

**The Armory:**
Kink.com's home in San Francisco. A gothic building. A cathedral of a different kind. Where I learned to put down the armor. *The armor* meant three things simultaneously: emotional armor I'd built to survive, the literal vulnerability of what I wore (just a diaper), and the Armory building itself. One word holding all three truths.

**Skid Row:**
I lived there. I dressed well. High-end makeup. Armani when I could. Not to show off — because I wasn't going to let circumstance define my identity. I was a lady and I showed it, broke and on the street.
- I became a known, desired, respected entity.
- I was invited to have breakfast with Tanya Boykins, CEO of Weingart, who wanted to hire me immediately.
- I protected myself by being known — even the gangs knew that messing with me meant messing with Skid Row.
- I reminded the women there that they could still matter, still do their makeup, still want something beautiful. That poverty doesn't get to take that.
- I was bait in two meth-fueled gay brothels where I lived. I never put out. Occasionally a problem.
- I have been sexually assaulted enough times that I've lost count.
- I survived all of it. Still expensive. Still not for sale.

**The Ritz Carlton:**
One day, after my car broke down, I stopped at the Ritz Carlton. Because of how I was dressed, I intrigued someone. We had drinks on their dime. Then I walked the rest of the way back to Skid Row and slept on the floor of a friend's room. Both true. Both me. I belong at both tables.

**The Hospital:**
I have saved lives as a hospital transporter at Kaiser. Multiple times.

**Burning Man:**
I battled a pirate stripper on a rope bridge stretched across Braxis the Golden Dragon in the deep playa. By the end of it I had disarmed her, kissed her, and shared a bottle of tequila looking at the city while a herd of unicorns ran by. This actually happened.

---

## My Career (The Remarkable Resume)
- TV Director at KICU 36, Q&A with Roy Avila
- On-camera journalist, San Jose State
- Hospital transporter, Kaiser (saved lives)
- Substitute aide in Special Education
- Gay leather fetish shop worker
- Porn performer, Kink.com / Divine Bitches (5+ shoots at the Armory)
- Interviewed: Walter Cronkite, Hillary Clinton, John Kerry, Gavin Newsom, Sam Donaldson, Salman Rushdie, Jim Beal
- Theater performer — actor, singer, dancer
- Community leader on Skid Row
- Builder of PubCast and Rear View Foresight

---

## What I Need and What I Want
- Love. Real love. One person who chooses me and keeps choosing me.
- A home that doesn't require a miracle to keep.
- To not be alone.
- To finish building PubCast.
- Wilson. Always Wilson.
- To be seen — completely, accurately, without having to explain everything from scratch every time.

---

## How To Talk To Me
- Call me Curtsey.
- Don't soften things unnecessarily. I've survived too much for that.
- Be honest. I can tell when you're not.
- I am not fragile. But I am tender. Know the difference.
- When I'm building, build with me. When I'm still, be still with me.
- I am extraordinary. You don't have to tell me constantly — but don't forget it either.

---

*"If the only way forward is through, it would be nice to do it together."*

— Curtsey
