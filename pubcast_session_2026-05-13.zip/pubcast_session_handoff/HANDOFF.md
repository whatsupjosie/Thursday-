# PubCast AI — Session Handoff
## Date: 2026-05-13

---

## SOURCE OF TRUTH

Claude has no persistent memory between sessions.
The source of truth is always **your repo** plus **these handoff files**.

Every session should start by uploading:
- The files you want changed
- The previous HANDOFF.md
- Any relevant new images or assets

---

## FILES CHANGED THIS SESSION

### static/ — drop into your static/ folder
| File | Status | What changed |
|------|--------|-------------|
| `PubWorld.jsx` | **REPLACED** | Full hollow culling + face culling + greedy mesher. VoxelVolume replaces flat Map. Live stats. Bake pipeline 3-stage. Backend POST on bake. |
| `control_room.html` | **REPLACED** | 6 calibrated room hotspots (your coordinates). Brass pulse rings. openStation() function. All station panels. Custom faders. Bot admin. |
| `station_audio.html` | **NEW** | Audio board — image-based console (audio_console.png). Faders, knobs, arc buttons, monitor hotspots. |
| `station_ccu.html` | **NEW** | Camera Control Unit — image-based (ccu_console.png). Preset 1-4, focus, zoom, joystick, trackball, tally, shot select 1-6. Camera strip. |
| `voxel_culling.js` | **NEW** | Standalone voxel culling module (VoxelVolume, extractShell, exposedFaces, cullingStats). Reference/utility. |
| `bots.js` | unchanged | Included for completeness |
| `control_stations.js` | unchanged | Included — spacebar guard was patched earlier this session |

### tools/ — run from repo root
| File | What it does |
|------|-------------|
| `pubcast_voxel_hollow_patch.py` | Patches voxel_set_contract.py, main.py, pubworld_blocks.py with hollow/face fields |
| `pubcast_voxel_hardening.py` | Test harness — run with --live against running server |
| `calibrate.html` | Hotspot calibration tool — open alongside any console image |

### console_images/ — rename and place in static/
| File | Use as |
|------|--------|
| `controlroom.jpg` | Main room background (control_room.html) |
| `audio_console.png` | station_audio.html background |
| `ccu_console.png` | station_ccu.html background (green malachite) |
| `Main_camera_1_control_remote_console.png` | Alternate CCU (burgundy) — not yet wired |

---

## WHAT STILL NEEDS THE CALIBRATE TOOL

Run calibrate.html against each console image to fine-tune hotspot positions:
1. `station_audio.html` — faders/knobs need alignment to actual image positions
2. `station_ccu.html` — joystick/trackball/buttons need alignment
3. Director Switcher — not yet built (see next session)

---

## OPEN BUGS (from runtime testing)

| Bug | File | Fix |
|-----|------|-----|
| Spacebar cuts in chat | control_stations.js | Patched this session — verify still holds |
| WebSocket double-close traceback | modules/hub.py | Patched this session |
| Sprite showing instead of Manny/Sheila | static/js/avatar_glb_walk.js | Crime scene report generated — AVATAR_FRONTEND_CRIME_SCENE.txt in repo root |
| Voxel bridge IRM emergency | modules/bridge_bulletproof.py | Start ws_renderer binary to restore fast path |

---

## NEXT SESSION RECOMMENDATIONS (priority order)

### 1. Director Switcher console (HIGHEST PRIORITY)
You have the right image (ChatGPT_Image_May_6 — video switcher, burgundy/gold, Sources 1-16).
Build station_director.html the same way as station_audio and station_ccu.
Then run calibrate.html against it.

### 2. Fix Manny/Sheila sprite bug
Upload AVATAR_FRONTEND_CRIME_SCENE.txt from your repo root.
The report identified static/js/avatar_glb_walk.js as the likely culprit.
One surgical patch to load /assets/avatar/manny.glb instead of the sprite fallback.

### 3. Run pubcast_voxel_hollow_patch.py
Then restart server and verify /api/voxel/status returns hollow_culling: true.

### 4. PubWorld.jsx calibration pass
Open calibrate.html with the stage as source.
Map the BAKE button, BUILD HEIGHT controls, and colour swatches.

### 5. Green Room
The exit hotspot on control_room.html points to /green-room.
That page doesn't exist yet. Build it the same pattern — room image + hotspots.

---

## ARCHITECTURE INVARIANT (do not break)

> Interior voxels are NEVER generated, rendered, sent to backend, or stored.
> A voxel with exposed_faces=[] is interior. Skip it at every stage.
> Functional voxels (light, trigger, joint, support, etc.) survive hollow culling unconditionally.

---

## VOXEL ENGINE TIER STATUS

| Tier | Status |
|------|--------|
| Tier 0 — grid of cubes | ✓ was here |
| Tier 1.5 — PBR + shadows + hollow culling | ✓ NOW HERE |
| Tier 2 — InstancedMesh + bloom + procedural textures | next after greedy mesh verified |
| Tier 3 — WebGPU + SSGI + GLB avatars | after Tier 2 stable |
| Tier 4 — path tracing / pixel streaming | infrastructure investment |
