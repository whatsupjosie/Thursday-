"""
pubcast_voxel_hardening.py
══════════════════════════
Test, harden, and debug the PubCast voxel engine stack.

Covers:
  1. Module import audit
  2. Bridge connection + path audit
  3. Asset manager smoke test
  4. voxel_llm_adapter provider default audit
  5. voxel_set_contract smoke test
  6. /api/voxel/status live endpoint check (if server running)
  7. /api/voxel/generate live smoke test (if server running)
  8. Known bug report + patch recommendations

Run from repo root:
  .\.venv\Scripts\python pubcast_voxel_hardening.py

Run against live server:
  .\.venv\Scripts\python pubcast_voxel_hardening.py --live
"""

from __future__ import annotations
import sys, json, argparse, traceback
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

PASS="PASS"; FAIL="FAIL"; WARN="WARN"; SKIP="SKIP"
SEP = "─" * 72
results: list[tuple[str,str,str]] = []

def record(label, status, detail=""):
    results.append((label, status, detail))
    icon = {"PASS":"✓","FAIL":"✗","WARN":"⚠","SKIP":"·"}.get(status,"?")
    print(f"  {icon}  {label}")
    if detail:
        for line in detail.splitlines()[:6]:
            print(f"       {line}")

# ── 1. IMPORT AUDIT ──────────────────────────────────────────────────────────
print(f"\n{SEP}\n1. MODULE IMPORT AUDIT\n{SEP}")

required = [
    ("modules.voxel_asset_manager",     "VoxelAssetManager"),
    ("modules.voxel_llm_adapter",       "generate_with_cloud"),
    ("modules.voxel_studio_integration","VoxelStudioIntegration"),
    ("modules.voxel_set_contract",      "VoxelSetContract"),
]
imported = {}
for mod, attr in required:
    try:
        m = __import__(mod, fromlist=[attr])
        obj = getattr(m, attr, None)
        if obj is None:
            record(f"{mod}.{attr}", FAIL, f"{attr} missing from module")
        else:
            imported[mod] = obj
            record(f"{mod}.{attr}", PASS)
    except ImportError as e:
        record(f"{mod}.{attr}", FAIL, str(e))
    except Exception as e:
        record(f"{mod}.{attr}", FAIL, traceback.format_exc(limit=2))

bridge_class = None
for mod, attr in [("modules.bridge_bulletproof","VoxelBridge"),("modules.bridge","VoxelBridge")]:
    try:
        m = __import__(mod, fromlist=[attr])
        bridge_class = getattr(m, attr, None)
        if bridge_class:
            record(f"VoxelBridge via {mod}", PASS); break
    except ImportError:
        continue
    except Exception as e:
        record(f"VoxelBridge via {mod}", WARN, str(e))
if not bridge_class:
    record("VoxelBridge (any path)", FAIL, "Neither bridge module importable")

# ── 2. BRIDGE AUDIT ──────────────────────────────────────────────────────────
print(f"\n{SEP}\n2. BRIDGE CONNECTION AUDIT\n{SEP}")
DATA_DIR = ROOT / "data"
bridge = None
if bridge_class:
    try:
        bridge = bridge_class(DATA_DIR)
        record("VoxelBridge(DATA_DIR)", PASS)
    except Exception as e:
        record("VoxelBridge(DATA_DIR)", FAIL, str(e))

if bridge:
    try:
        if hasattr(bridge, "connect"):
            ok = bridge.connect()
            record("bridge.connect()", PASS if ok else WARN,
                   "TCP connected" if ok else "Fallback/emergency path — ws_renderer not running (expected)")
        else:
            record("bridge.connect()", SKIP, "No connect() method")
    except Exception as e:
        record("bridge.connect()", WARN, str(e))

    try:
        st = bridge.status() if (hasattr(bridge,"status") and callable(bridge.status)) else getattr(bridge,"status","?")
        emergency = "EMERGENCY" in str(st).upper()
        record("bridge.status()", WARN if emergency else PASS, str(st)[:120])
    except Exception as e:
        record("bridge.status()", FAIL, str(e))

    try:
        if hasattr(bridge, "send_command"):
            r = bridge.send_command("PING", {})
            record("bridge.send_command(PING)", PASS, str(r)[:80])
        else:
            record("bridge.send_command", SKIP)
    except Exception as e:
        record("bridge.send_command(PING)", WARN, str(e))

# ── 3. ASSET MANAGER ─────────────────────────────────────────────────────────
print(f"\n{SEP}\n3. ASSET MANAGER SMOKE TEST\n{SEP}")
VAM = imported.get("modules.voxel_asset_manager")
asset_manager = None

if VAM:
    lib = DATA_DIR / "voxel_asset_library.json"
    if not lib.exists():
        lib.parent.mkdir(parents=True, exist_ok=True)
        lib.write_text(json.dumps({"assets":[],"version":"1.0"}), encoding="utf-8")
        record("voxel_asset_library.json", WARN, "Created empty stub")
    else:
        record("voxel_asset_library.json", PASS, str(lib))

    try:
        asset_manager = VAM(library_path=lib)
        record("VoxelAssetManager()", PASS)
    except Exception as e:
        record("VoxelAssetManager()", FAIL, str(e))

    if asset_manager:
        try:
            assets = asset_manager.get_all_assets()
            record("get_all_assets()", PASS, f"{len(assets)} assets")
        except Exception as e:
            record("get_all_assets()", FAIL, str(e))

        try:
            record("search_assets('stage')", PASS,
                   f"{len(asset_manager.search_assets('stage'))} results")
        except Exception as e:
            record("search_assets()", FAIL, str(e))

        if bridge and hasattr(asset_manager, "config"):
            try:
                asset_manager.config["bridge"] = bridge
                record("bridge → asset_manager.config", PASS)
            except Exception as e:
                record("bridge → asset_manager.config", FAIL, str(e))

        try:
            if hasattr(asset_manager, "sync_with_rust_engine"):
                result = asset_manager.sync_with_rust_engine(pete=None)
                record("sync_with_rust_engine(pete=None)", PASS, str(result)[:80])
            else:
                record("sync_with_rust_engine", SKIP, "Method not present")
        except Exception as e:
            record("sync_with_rust_engine", WARN, str(e))

        voxel_sets = DATA_DIR / "pubworld" / "voxel_sets"
        if voxel_sets.exists():
            saved = list(voxel_sets.glob("*.json"))
            record(f"voxel_sets/ discovery", PASS, f"{len(saved)} sets")
        else:
            record("voxel_sets/ dir", WARN, f"Not found: {voxel_sets}")
else:
    record("Asset manager tests", SKIP, "Module not importable")

# ── 4. LLM ADAPTER AUDIT ─────────────────────────────────────────────────────
print(f"\n{SEP}\n4. voxel_llm_adapter PROVIDER DEFAULT AUDIT\n{SEP}")
adapter_path = ROOT / "modules" / "voxel_llm_adapter.py"
if adapter_path.exists():
    text = adapter_path.read_text(encoding="utf-8", errors="ignore")
    if 'provider="local"' in text or "provider='local'" in text:
        record("provider default = local", PASS)
    elif 'provider="auto"' in text or "provider='auto'" in text:
        record("provider default", FAIL,
               "Still 'auto' — cloud/Ollama fires before local engine.\n"
               "Fix: change signature to provider='local'")
    else:
        record("provider default", WARN, "Cannot detect — inspect manually")

    if "import httpx" in text:
        if "try" in text:
            record("httpx optional", PASS)
        else:
            record("httpx optional", WARN, "Unconditional import — crashes without httpx")
    else:
        record("httpx dependency", PASS, "Not referenced")

    # Return shape check — must be (result, provider_used) where result=(label,blocks)
    if "return" in text:
        record("return path present", PASS)
    else:
        record("return path", WARN, "No return statement found")
else:
    record("voxel_llm_adapter.py", FAIL, "File not found")

# ── 5. VOXEL SET CONTRACT ─────────────────────────────────────────────────────
print(f"\n{SEP}\n5. VOXEL SET CONTRACT SMOKE TEST\n{SEP}")
VSC = imported.get("modules.voxel_set_contract")
if VSC:
    try:
        contract = VSC(
            label="hardening_test",
            blocks=[{"x":0,"y":0,"z":0,"type":"stone"},{"x":1,"y":0,"z":0,"type":"stone"}],
            ai_authority=False, sandbox_only=True,
        )
        record("VoxelSetContract create", PASS)
        valid, errors = contract.validate()
        record("contract.validate()", PASS if valid else FAIL,
               "\n".join(errors) if errors else "")
        out = DATA_DIR / "pubworld" / "voxel_sets" / "_hardening_test.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        contract.save(out)
        record("contract.save()", PASS)
        reloaded = VSC.load(out)
        v2, _ = reloaded.validate()
        record("contract reload+validate", PASS if v2 else FAIL)
    except Exception as e:
        record("VoxelSetContract", FAIL, traceback.format_exc(limit=3))
else:
    record("VoxelSetContract tests", SKIP,
           "Module not importable — may be missing from this repo copy.\n"
           "Source: CODEX session 2026-05-02 / modules/voxel_set_contract.py")

# ── 6+7. LIVE CHECKS ─────────────────────────────────────────────────────────
def live_checks(base):
    import urllib.request, urllib.error
    print(f"\n{SEP}\n6. LIVE /api/voxel/status\n{SEP}")
    try:
        with urllib.request.urlopen(f"{base}/api/voxel/status", timeout=5) as r:
            data = json.loads(r.read())
        record("/api/voxel/status", PASS, json.dumps(data))
        if not data.get("asset_manager"):
            record("  asset_manager=True", FAIL, "VoxelAssetManager did not init at boot")
        if not data.get("bridge"):
            record("  bridge present", WARN, "No bridge — ws_renderer not running (expected)")
        bs = data.get("bridge_status","")
        if bs and "EMERGENCY" in str(bs).upper():
            record("  bridge_status", WARN, f"{bs} — fallback path active")
    except Exception as e:
        record("/api/voxel/status", FAIL, str(e))

    print(f"\n{SEP}\n7. LIVE /api/voxel/generate smoke\n{SEP}")
    print("  NOTE: requires mod-role JWT. Will 401 without auth token.")
    print("  To test manually:")
    print(f"  curl -X POST {base}/api/voxel/generate \\")
    print('    -H "Content-Type: application/json" \\')
    print('    -H "Authorization: Bearer <mod_token>" \\')
    print('    -d \'{"prompt":"small stone platform","provider":"local"}\'')

# ── 8. KNOWN BUGS ─────────────────────────────────────────────────────────────
print(f"\n{SEP}\n8. KNOWN BUGS + RECOMMENDATIONS\n{SEP}")
bugs = [
    ("Bridge IRM emergency mode (score 25)",
     "ws_renderer TCP target not listening → File System fallback.\n"
     "Expected behaviour. Start ws_renderer binary to restore fast path.\n"
     "File: modules/bridge_bulletproof.py"),
    ("voxel_generate return shape contract",
     "main.py expects: result, provider_used = await voxel_generate(...)\n"
     "Then: label, blocks = result\n"
     "If adapter returns flat (label,blocks) tuple this unpacks wrong → 500 error.\n"
     "Verify: modules/voxel_llm_adapter.py line 'return (label, blocks), provider_str'"),
    ("/api/voxel/generate requires mod role",
     "Endpoint uses Depends(require_role('mod')) — 401/403 without token.\n"
     "For local dev add a TEST_BYPASS_AUTH env flag or use a dev token."),
    ("voxel_set_contract may be missing from older copies",
     "Added in CODEX session 2026-05-02.\n"
     "If import fails: copy from PubCast_AI_v6_codex_run_snapshot_2026-05-02.zip"),
    ("sync_with_rust_engine bridge None guard",
     "If bridge init fails the config key is never set.\n"
     "sync_with_rust_engine should guard: bridge = self.config.get('bridge')\n"
     "if bridge is None: return False"),
]
for title, detail in bugs:
    print(f"\n  ⚠  {title}")
    for line in detail.splitlines():
        print(f"       {line}")

# ── SUMMARY ───────────────────────────────────────────────────────────────────
print(f"\n{SEP}\nSUMMARY\n{SEP}")
passed  = sum(1 for _,s,_ in results if s==PASS)
failed  = sum(1 for _,s,_ in results if s==FAIL)
warned  = sum(1 for _,s,_ in results if s==WARN)
skipped = sum(1 for _,s,_ in results if s==SKIP)
print(f"  ✓ PASS:  {passed}")
print(f"  ✗ FAIL:  {failed}")
print(f"  ⚠ WARN:  {warned}")
print(f"  · SKIP:  {skipped}")
if failed:
    print("\n  FAILURES:")
    for l,s,d in results:
        if s==FAIL: print(f"    ✗  {l}")
print()
if   failed == 0 and warned <= 1: print("  ✓ Voxel engine healthy.")
elif failed == 0:                 print("  ⚠ Voxel engine degraded but runnable. Bridge fallback expected without ws_renderer.")
else:                             print("  ✗ Hard failures — address FAIL items before production use.")

report = ROOT / "VOXEL_HARDENING_REPORT.txt"
with open(report, "w", encoding="utf-8") as f:
    f.write("PUBCAST VOXEL ENGINE HARDENING REPORT\n" + "="*72 + "\n\n")
    for l,s,d in results:
        f.write(f"[{s}] {l}\n")
        if d:
            for line in d.splitlines(): f.write(f"       {line}\n")
print(f"\n  Report: {report}\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--base", default="http://127.0.0.1:8000")
    args = parser.parse_args()
    if args.live:
        live_checks(args.base)
