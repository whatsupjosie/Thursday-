# PubWorld.jsx — Fidelity Assessment & Upgrade Plan

## WHAT YOU ACTUALLY HAVE

This is a real, working Three.js voxel editor. Not a placeholder.

**Already working:**
- WebGLRenderer with PCFSoftShadowMap
- PerspectiveCamera with orbit/pan/zoom
- MeshStandardMaterial on every voxel (PBR-ready)
- Shadow casting/receiving on voxels and floor
- Raycasting for placement on voxels, baked meshes, and height planes
- Ghost voxel preview on hover
- Bake-to-mesh: merges voxel geometries by color group → single draw call per color
- Virtual camera prop with frustum lines + REC indicator
- Actor/performer proxy with mocap markers
- Ceiling rig with 5 SpotLights
- Key/fill/rim 3-point lighting setup
- Scene fog
- Resize handling
- Proper cleanup on unmount

**This is Tier 1.5.** The foundation is solid.

---

## WHAT'S MISSING FOR TIER 2 (Broadcast quality)

### 1. PERFORMANCE — biggest issue right now

Each voxel placed = new BoxGeometry + new MeshStandardMaterial.
At 500 voxels you have 500 draw calls. At 2000 it crawls.

**Fix: InstancedMesh**
Replace individual meshes with one InstancedMesh per color.
1000 voxels = still 1 draw call per color group. 10x-50x faster.

### 2. AMBIENT OCCLUSION
Flat MeshStandardMaterial with no AO makes voxels float.
They look pasted on rather than sitting in the scene.

**Fix: Per-voxel AO baking**
When placing a voxel, check its 6 neighbors.
Darken exposed edges slightly. 4 lines of math, huge visual impact.

### 3. POST-PROCESSING
No bloom, no color grading, no vignette.
The scene looks clinical and flat even with PBR materials.

**Fix: Three.js EffectComposer**
- UnrealBloomPass (emissive elements glow)
- ColorGradePass (warm amber for Art Deco)
- VignettePass (frames the scene)

### 4. TEXTURE MAPS
Every voxel uses a flat color. No surface detail.
Stone looks like painted plastic. Wood looks the same.

**Fix: Material atlas**
One canvas-generated texture per material type.
Stone: procedural noise. Wood: grain lines. Brass: subtle specular map.
No external files needed — generated in JS at load time.

### 5. BAKE PIPELINE → PUBCAST BACKEND
handleBake() merges geometry locally but never saves to the server.
The voxel_set_contract.py and VoxelAssetManager are waiting for this data.

**Fix: POST to /api/pubworld/props after bake**
Serialize voxel positions + colors → send to backend → saved as VoxelSet.

### 6. LOAD FROM BACKEND
No way to load existing scenes or voxel sets from the server.
The builder is an island.

**Fix: Load button → GET /api/voxel/assets → populate scene**

---

## UPGRADE DIFF — what to change

### A. InstancedMesh pool (replaces individual meshes)

```javascript
// Replace the voxMap (Map of individual meshes) with:
class VoxelPool {
  constructor(scene) {
    this.scene = scene;
    this.pools = new Map(); // hex → {mesh: InstancedMesh, slots: Map<key, index>, count: 0}
    this.dummy = new THREE.Object3D();
  }

  getOrCreate(hex) {
    if (!this.pools.has(hex)) {
      const mesh = new THREE.InstancedMesh(
        new THREE.BoxGeometry(0.96, 0.96, 0.96),
        new THREE.MeshStandardMaterial({
          color: hex,
          roughness: 0.65,
          metalness: 0.06,
        }),
        4096  // max instances per color
      );
      mesh.castShadow = mesh.receiveShadow = true;
      mesh.count = 0;
      this.scene.add(mesh);
      this.pools.set(hex, { mesh, slots: new Map(), free: [] });
    }
    return this.pools.get(hex);
  }

  place(x, y, z, hex) {
    const pool = this.getOrCreate(hex);
    const key = `${x},${y},${z}`;
    if (pool.slots.has(key)) return;
    const idx = pool.free.length ? pool.free.pop() : pool.mesh.count++;
    this.dummy.position.set(x, y, z);
    this.dummy.updateMatrix();
    pool.mesh.setMatrixAt(idx, this.dummy.matrix);
    pool.mesh.instanceMatrix.needsUpdate = true;
    pool.slots.set(key, idx);
  }

  remove(x, y, z, hex) {
    const pool = this.pools.get(hex); if (!pool) return;
    const key = `${x},${y},${z}`;
    const idx = pool.slots.get(key); if (idx === undefined) return;
    // Hide by scaling to 0
    this.dummy.scale.setScalar(0);
    this.dummy.updateMatrix();
    pool.mesh.setMatrixAt(idx, this.dummy.matrix);
    pool.mesh.instanceMatrix.needsUpdate = true;
    pool.slots.delete(key);
    pool.free.push(idx);
  }

  dispose() {
    this.pools.forEach(({ mesh }) => {
      this.scene.remove(mesh);
      mesh.geometry.dispose();
      mesh.material.dispose();
    });
    this.pools.clear();
  }
}
```

### B. Procedural material textures

```javascript
function makeProceduralTexture(type, size = 64) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d');

  if (type === 'stone') {
    // Base
    ctx.fillStyle = '#888'; ctx.fillRect(0, 0, size, size);
    // Noise
    for (let i = 0; i < 400; i++) {
      const v = Math.floor(Math.random() * 40 + 100);
      ctx.fillStyle = `rgb(${v},${v},${v})`;
      ctx.fillRect(Math.random()*size, Math.random()*size, 2, 2);
    }
    // Cracks
    ctx.strokeStyle = 'rgba(0,0,0,0.15)'; ctx.lineWidth = 0.5;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(Math.random()*size, Math.random()*size);
      ctx.lineTo(Math.random()*size, Math.random()*size);
      ctx.stroke();
    }
  }

  if (type === 'wood') {
    ctx.fillStyle = '#8B5E3C'; ctx.fillRect(0, 0, size, size);
    for (let y = 0; y < size; y++) {
      const v = Math.sin(y * 0.8) * 15;
      ctx.fillStyle = `rgba(0,0,0,${0.05 + Math.abs(v) * 0.004})`;
      ctx.fillRect(0, y, size, 1);
    }
  }

  if (type === 'brass') {
    ctx.fillStyle = '#c8a44a'; ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 200; i++) {
      const v = Math.floor(Math.random() * 30 + 180);
      ctx.fillStyle = `rgba(${v},${Math.floor(v*0.8)},0,0.12)`;
      ctx.fillRect(Math.random()*size, Math.random()*size, 3, 1);
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}
```

### C. EffectComposer post-processing

```javascript
// At the top of the file, import:
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass }     from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { ShaderPass }     from 'three/examples/jsm/postprocessing/ShaderPass.js';

// In the useEffect, after renderer setup:
const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, cam));
composer.addPass(new UnrealBloomPass(
  new THREE.Vector2(W, H),
  0.35,   // strength — subtle, not neon
  0.4,    // radius
  0.85    // threshold — only bright emissives bloom
));

// In animate(), replace renderer.render() with:
composer.render();

// In onResize():
composer.setSize(W, H);
```

### D. Backend sync after bake

```javascript
// At end of handleBake(), after setSets():
const voxelData = {
  label: setName,
  blocks: [...colorGroups.entries()].flatMap(([hex, geos]) =>
    geos.map((g, i) => ({
      x: Math.round(eng.bakedList[eng.bakedList.length - colorGroups.size + i]?.position.x ?? 0),
      y: Math.round(eng.bakedList[eng.bakedList.length - colorGroups.size + i]?.position.y ?? 0),
      z: Math.round(eng.bakedList[eng.bakedList.length - colorGroups.size + i]?.position.z ?? 0),
      color_hex: `#${hex.toString(16).padStart(6,'0')}`,
      type: 'voxel',
    }))
  ),
  provider: 'manual_build',
};
fetch('/api/pubworld/props', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(voxelData),
}).catch(() => {}); // fire and forget
```

---

## PRIORITY ORDER

1. **InstancedMesh** — performance unlock. Do this first or nothing else matters at scale.
2. **EffectComposer + bloom** — biggest visual jump per line of code.
3. **Procedural textures** — no file deps, immediate material quality boost.
4. **Backend sync** — connects the builder to the server pipeline.
5. **Load from backend** — closes the loop.

---

## TIER 3 PATH (after above is solid)

- Replace `new THREE.WebGLRenderer` with `new THREE.WebGPURenderer`
  - Three.js r165+ ships WebGPU renderer — same API, dramatically better perf
- Add `GTAOPass` (Ground Truth Ambient Occlusion) from three/examples
- Add `SSRPass` (Screen Space Reflections) for brass/floor surfaces
- Load Manny.glb / Sheila.glb via GLTFLoader, replace actor proxy
- SkeletonHelper + AnimationMixer for mocap playback on GLB avatars

## TIER 4 PATH

- Detect GPU tier at startup, swap renderer factory
- Server-side render path: POST scene state → receive WebRTC stream
- Three.js WebGPU path tracer (r158+) for still-frame photorealism
