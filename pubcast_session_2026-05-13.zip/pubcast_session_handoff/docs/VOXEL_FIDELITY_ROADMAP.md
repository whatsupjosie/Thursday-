# PubCast Voxel Engine — Fidelity Roadmap
## From "runs on a potato" to "photorealistic ceiling"

---

## HONEST CURRENT STATE

The voxel stack as it exists has three layers:

```
TEXT PROMPT
    ↓
voxel_llm_adapter.py        ← generates block coordinates (JSON)
    ↓
VoxelAssetManager           ← catalogues + serves assets
    ↓
VoxelBridge (Python)        ← dispatches to Rust via TCP or file fallback
    ↓
ws_renderer (Rust binary)   ← THE ACTUAL RENDERER (currently disconnected)
    ↓
pubworld_stage.html         ← browser display (currently Three.js CDN stub)
```

**The builder has no 3D renderer.** It is a JSON scene composer.
**The stage canvas is a placeholder.** The Rust bridge is in IRM emergency/fallback.
**The avatars (Manny/Sheila GLBs) exist but the browser page never loads them.**

This is not catastrophic. It means the geometry pipeline is real
but the display pipe is incomplete. You have a working engine
with a missing windshield.

---

## THE FIDELITY TIERS

### TIER 0 — Where you are now
- Voxel blocks as `[x, y, z]` int triples
- No lighting model
- No materials
- No normals
- Browser display: CSS/canvas placeholder
- Rust renderer: disconnected / file fallback

**Ceiling:** grid of cubes, Minecraft 2011

---

### TIER 1 — "Runs on anything" (Low end floor)
**Target:** Any machine with a browser. Raspberry Pi. Old laptop.

**What to add:**
- Three.js `BoxGeometry` + `MeshLambertMaterial` in the browser
- `InstancedMesh` for voxel blocks (one draw call per material type)
- A single directional light + ambient
- Simple flat colour palette per block type
- 30fps target, 10k blocks max

**Block schema upgrade:**
```json
{"x":0,"y":0,"z":0,"type":"stone","color":"#8a8a8a"}
```

**Cost:** ~300 lines of Three.js. Works without Rust bridge.
**Fidelity:** Stylised, readable, fast. Appropriate for low-end.

---

### TIER 2 — "Broadcast quality" (Mid target)
**Target:** Modern laptop, integrated GPU.

**What to add:**
- `MeshStandardMaterial` (PBR — physically based rendering)
  - roughness map per block type
  - metalness map for brass/gold surfaces
  - normal maps for stone/wood grain
- Ambient occlusion baked per-chunk (simple AO, no raytracing)
- Soft shadows (`PCFSoftShadowMap`)
- Post-processing: bloom, slight vignette, colour grading (Three.js `EffectComposer`)
- LOD — distant chunks use merged low-poly geometry
- 60fps target, 100k blocks

**Block schema upgrade:**
```json
{
  "x":0,"y":0,"z":0,
  "type":"mahogany_wood",
  "material": {"roughness":0.7,"metalness":0.0,"normal_map":"wood_01"}
}
```

**Cost:** Three.js EffectComposer + post pass, material atlas.
**Fidelity:** Looks like a polished game. Art Deco broadcast set reads correctly.

---

### TIER 3 — "Film quality" (High end)
**Target:** Dedicated GPU, RTX class.

**What to add:**
- Move renderer from Three.js → **Babylon.js** or **Three.js WebGPU backend**
  - WebGPU gives access to compute shaders, real-time GI
- **Screen Space Global Illumination (SSGI)** or **VXGI** (voxel-based GI — ironic fit)
- **Real-time ray-traced reflections** (WebGPU compute)
- **Volumetric lighting** — god rays through studio windows, dust particles
- **Subsurface scattering** for avatar skin
- **Temporal Anti-Aliasing (TAA)**
- Avatar mesh: replace voxel proxy with full GLTF/GLB at this tier
- 60fps target, no block limit (GPU instancing + culling)

**Cost:** Major renderer rewrite. Babylon.js PBR pipeline is the fastest path.
**Fidelity:** Indistinguishable from pre-rendered at correct camera settings.

---

### TIER 4 — "Earth systems ceiling"
**Target:** Multi-GPU workstation, server-side rendering.

**What to add:**
- **Server-side WebRTC stream** — render on server GPU, stream to browser
  - Browser becomes a video player. Client hardware irrelevant.
- **Path tracing** via Three.js WebGPU path tracer (ships in r158+)
  - Noise-free photorealism given enough samples
- **Neural radiance fields (NeRF)** for environment capture and playback
- **Gaussian Splatting** for avatar and set reconstruction from photos
- **Unreal Engine Pixel Streaming** as optional backend
  - PubCast Python sends scene state → Unreal renders → WebRTC → browser

**Cost:** Infrastructure investment, not just code.
**Fidelity:** Movie VFX quality. Photorealistic.

---

## THE ADAPTIVE TIER SELECTOR

The right pattern for PubCast is **automatic tier detection**:

```javascript
// In pubworld_stage.html on load:
async function detectRenderTier() {
  const gl = document.createElement('canvas').getContext('webgl2');
  const gpu = await navigator.gpu?.requestAdapter?.();

  if (gpu) {
    const info = await gpu.requestAdapterInfo?.();
    const isHighEnd = gpu && (info?.description || '').match(/RTX|RX 6|RX 7|M[123] Pro/i);
    return isHighEnd ? 'tier3' : 'tier2_webgpu';
  }

  if (gl) {
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    const renderer = dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : '';
    const isMid = renderer.match(/GTX|RX 5|Intel Iris Xe|Apple M/i);
    return isMid ? 'tier2' : 'tier1';
  }

  return 'tier0'; // canvas 2D fallback
}
```

This feeds into a renderer factory:
```javascript
const tier = await detectRenderTier();
const renderer = RendererFactory.create(tier, canvas, scene_data);
```

E-Pete / the orchestrator can also **force a tier** via production state:
```python
POST /api/state/production
{"render_tier": "tier2", "reason": "streaming_mode"}
```

---

## IMMEDIATE NEXT STEPS (in order)

### Step 1 — Wire the Three.js viewport into pubworld_stage.html
Replace the canvas placeholder with a real Three.js scene.
Use `InstancedMesh` for voxel blocks.
This is Tier 1. One session. Unblocks everything else.

### Step 2 — Connect the Rust bridge
Start `ws_renderer` binary. The IRM emergency fallback goes away.
Block data flows Python → Rust → browser at full speed.

### Step 3 — Block schema upgrade
Add `material_type`, `roughness`, `color_hex` to the block contract.
`voxel_set_contract.py` already has the validation layer. Just extend it.

### Step 4 — PBR material atlas
One JSON file: block_type → {roughness, metalness, normal_map, albedo}.
Mahogany gets wood grain. Brass gets metalness=0.9. Stone gets roughness=0.85.
This alone gets you to Tier 2 visual quality.

### Step 5 — Post-processing pass
Three.js EffectComposer: bloom + colour grade.
Gets the Art Deco broadcast look. Warm amber highlights on brass.

### Step 6 — Avatar integration
Load Manny.glb / Sheila.glb into the Three.js scene.
They already exist. They just need to be `GLTFLoader`'d into the viewport.

---

## KEY ARCHITECTURAL PRINCIPLE

> The Rust bridge (`ws_renderer`) is the compute layer.
> The browser (Three.js / Babylon / WebGPU) is the display layer.
> Python (E-Pete / voxel_llm_adapter) is the governor.
> AI generates intent. Engines do the work.

Never put photorealism logic in the LLM adapter.
The adapter outputs geometry. The renderer decides how beautiful it is.
Tier selection is runtime, not compile-time.

---

## FILE MAP FOR NEXT SESSION

| File | What to do |
|------|-----------|
| `static/pubworld_stage.html` | Replace canvas placeholder with Three.js InstancedMesh scene |
| `modules/voxel_set_contract.py` | Add material_type, color_hex fields to block schema |
| `data/materials/block_materials.json` | Create PBR material atlas |
| `static/js/voxel_renderer.js` | New file — tier-aware renderer factory |
| `rust_crate/src/ws_renderer.rs` | Audit geometry output format — does it match browser expectations? |
| `modules/bridge_bulletproof.py` | Add LOAD_SCENE command with material data passthrough |
