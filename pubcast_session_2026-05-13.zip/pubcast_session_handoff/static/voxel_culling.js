/**
 * PubCast — Hollow Voxel Culling System
 * ════════════════════════════════════════════════════════════════
 * 
 * RULE: A voxel is only generated/rendered if:
 *   1. At least one of its 6 faces is exposed (neighbour is air), OR
 *   2. It is tagged as functionally significant (wire, support, trigger, interior_visible)
 *
 * Corollary: Fully enclosed interior voxels are NEVER generated.
 * Exception:  Functional voxels (lights, triggers, joints, named parts) always survive.
 *
 * This is surface extraction, not mesh simplification.
 * The geometry is still voxels. We just skip the hidden ones.
 *
 * Usage (as a module alongside PubWorld.jsx):
 *   import { shouldExist, rebuildShell, tagFunctional, VoxelVolume } from './voxel_culling';
 */

// ─── Constants ────────────────────────────────────────────────────────────────
const FACE_OFFSETS = [
  [ 1,  0,  0],  // +X right
  [-1,  0,  0],  // -X left
  [ 0,  1,  0],  // +Y top
  [ 0, -1,  0],  // -Y bottom
  [ 0,  0,  1],  // +Z front
  [ 0,  0, -1],  // -Z back
];

// Functional tags — voxels with these are NEVER culled regardless of exposure
const FUNCTIONAL_TAGS = new Set([
  'light',          // emits light
  'trigger',        // collision trigger zone
  'joint',          // skeletal attachment point
  'support',        // structural — weight-bearing
  'interior_visible', // camera can see inside (glass wall, cutaway)
  'wire',           // cable/conduit routing
  'audio_source',   // speaker or mic pickup zone
  'camera_target',  // look-at anchor
  'spawn',          // avatar spawn point
  'interactive',    // clickable / player-interactable
]);

// ─── VoxelVolume ─────────────────────────────────────────────────────────────
/**
 * A sparse set of voxels with O(1) neighbour lookup.
 * Keys are "x,y,z" integers. Values are { color, tag, material }.
 *
 * This replaces the raw Map<key,mesh> in PubWorld.jsx.
 * The renderer reads from this — it never decides what exists.
 */
export class VoxelVolume {
  constructor() {
    this._voxels = new Map();       // "x,y,z" → VoxelData
    this._functional = new Set();   // keys of functional voxels
    this._shell = null;             // cached shell key set, invalidated on change
  }

  // ── Low-level key ────────────────────────────────────────────────────────
  static key(x, y, z) {
    return `${Math.round(x)},${Math.round(y)},${Math.round(z)}`;
  }

  static fromKey(k) {
    const [x, y, z] = k.split(',').map(Number);
    return { x, y, z };
  }

  // ── Read ─────────────────────────────────────────────────────────────────
  has(x, y, z)  { return this._voxels.has(VoxelVolume.key(x, y, z)); }
  get(x, y, z)  { return this._voxels.get(VoxelVolume.key(x, y, z)); }
  get size()    { return this._voxels.size; }
  get shellSize() { return this.shell.size; }

  // ── Write ─────────────────────────────────────────────────────────────────
  /**
   * Place a voxel.
   * @param {number} x y z  — integer grid coordinates
   * @param {object} data   — { color: 0xrrggbb, tag?: string, material?: string }
   */
  place(x, y, z, data = {}) {
    const k = VoxelVolume.key(x, y, z);
    this._voxels.set(k, { color: data.color ?? 0xffffff, tag: data.tag ?? null, material: data.material ?? 'default' });
    if (data.tag && FUNCTIONAL_TAGS.has(data.tag)) this._functional.add(k);
    this._shell = null; // invalidate cache
    // Also invalidate shell for all 6 neighbours (they may now be enclosed)
    FACE_OFFSETS.forEach(([dx, dy, dz]) => this._shell = null);
  }

  remove(x, y, z) {
    const k = VoxelVolume.key(x, y, z);
    this._voxels.delete(k);
    this._functional.delete(k);
    this._shell = null;
  }

  tagFunctional(x, y, z, tag) {
    const k = VoxelVolume.key(x, y, z);
    if (!this._voxels.has(k)) return false;
    const v = this._voxels.get(k);
    v.tag = tag;
    if (FUNCTIONAL_TAGS.has(tag)) this._functional.add(k);
    this._shell = null;
    return true;
  }

  clear() {
    this._voxels.clear();
    this._functional.clear();
    this._shell = null;
  }

  // ── Shell computation ─────────────────────────────────────────────────────
  /**
   * THE CORE RULE:
   * 
   * A voxel is in the shell (should be rendered) if:
   *   - It is functional (always included), OR
   *   - At least one of its 6 face-adjacent neighbours is absent (exposed to air)
   *
   * Interior voxels — all 6 neighbours present, not functional — are excluded.
   */
  get shell() {
    if (this._shell) return this._shell;
    const shell = new Set();

    this._voxels.forEach((data, k) => {
      // Functional voxels always survive
      if (this._functional.has(k)) {
        shell.add(k);
        return;
      }

      const { x, y, z } = VoxelVolume.fromKey(k);

      // Check all 6 faces
      const exposed = FACE_OFFSETS.some(([dx, dy, dz]) =>
        !this._voxels.has(VoxelVolume.key(x + dx, y + dy, z + dz))
      );

      if (exposed) shell.add(k);
      // Else: fully enclosed interior voxel — not generated
    });

    this._shell = shell;
    return shell;
  }

  /**
   * Returns only the voxels that should actually be rendered.
   * Interior voxels are absent from this list.
   */
  shellEntries() {
    const result = [];
    this.shell.forEach(k => {
      result.push({ key: k, ...VoxelVolume.fromKey(k), ...this._voxels.get(k) });
    });
    return result;
  }

  /**
   * Returns voxels that were culled (for debug/audit).
   */
  culledEntries() {
    const result = [];
    this._voxels.forEach((data, k) => {
      if (!this.shell.has(k)) {
        result.push({ key: k, ...VoxelVolume.fromKey(k), ...data, reason: 'enclosed_interior' });
      }
    });
    return result;
  }

  /**
   * Stats for the status bar.
   */
  stats() {
    const total     = this._voxels.size;
    const shell     = this.shell.size;
    const culled    = total - shell;
    const functional = this._functional.size;
    const pctCulled = total > 0 ? Math.round((culled / total) * 100) : 0;
    return { total, shell, culled, functional, pctCulled };
  }

  // ── Serialisation ─────────────────────────────────────────────────────────
  /**
   * Export for /api/pubworld/props — only shell voxels are included.
   * Interior voxels are intentionally excluded from the wire format.
   */
  toJSON(label = 'unnamed') {
    return {
      label,
      hollow: true,
      stats: this.stats(),
      blocks: this.shellEntries().map(v => ({
        x: v.x, y: v.y, z: v.z,
        color_hex: `#${v.color.toString(16).padStart(6, '0')}`,
        material: v.material,
        tag: v.tag,
        type: v.tag && FUNCTIONAL_TAGS.has(v.tag) ? v.tag : 'surface',
      })),
    };
  }

  static fromJSON(json) {
    const vol = new VoxelVolume();
    (json.blocks || []).forEach(b => {
      const color = parseInt((b.color_hex || '#ffffff').slice(1), 16);
      vol.place(b.x, b.y, b.z, { color, tag: b.tag, material: b.material });
    });
    return vol;
  }
}

// ─── Standalone helpers (for use without the full volume class) ───────────────

/**
 * Given a flat array of {x,y,z} blocks, return only the shell.
 * Drop-in for any existing block array before sending to the renderer.
 *
 * @param {Array<{x,y,z,...}>} blocks
 * @param {Set<string>} functionalKeys  optional — keys that survive regardless
 * @returns {Array<{x,y,z,...}>}
 */
export function extractShell(blocks, functionalKeys = new Set()) {
  const occupied = new Set(blocks.map(b => VoxelVolume.key(b.x, b.y, b.z)));

  return blocks.filter(b => {
    const k = VoxelVolume.key(b.x, b.y, b.z);
    if (functionalKeys.has(k)) return true; // always keep

    return FACE_OFFSETS.some(([dx, dy, dz]) =>
      !occupied.has(VoxelVolume.key(b.x + dx, b.y + dy, b.z + dz))
    );
  });
}

/**
 * How many voxels would be culled from this block array?
 * Use this to report savings to the operator.
 */
export function cullingStats(blocks) {
  const shell = extractShell(blocks);
  const total   = blocks.length;
  const visible = shell.length;
  const culled  = total - visible;
  return {
    total,
    visible,
    culled,
    pctCulled: total > 0 ? Math.round((culled / total) * 100) : 0,
    savingsMsg: `${culled} interior voxels culled (${Math.round((culled/Math.max(1,total))*100)}% of volume not generated)`,
  };
}

// ─── Face-level optimisation: Greedy meshing hint ────────────────────────────
/**
 * For each voxel in the shell, returns only the FACES that are exposed.
 * This is the data a greedy mesher needs to merge coplanar faces into quads.
 *
 * Returns: Array<{ x,y,z, faces: string[] }>
 * where faces is a subset of ['+x','-x','+y','-y','+z','-z']
 */
const FACE_NAMES = ['+x','-x','+y','-y','+z','-z'];

export function exposedFaces(blocks) {
  const occupied = new Set(blocks.map(b => VoxelVolume.key(b.x, b.y, b.z)));

  return blocks
    .map(b => {
      const faces = FACE_OFFSETS
        .map(([dx, dy, dz], i) => ({
          name: FACE_NAMES[i],
          exposed: !occupied.has(VoxelVolume.key(b.x + dx, b.y + dy, b.z + dz)),
        }))
        .filter(f => f.exposed)
        .map(f => f.name);

      return faces.length > 0 ? { ...b, faces } : null;
    })
    .filter(Boolean);
}

// ─── PubWorld.jsx integration patch ──────────────────────────────────────────
/*
  CHANGES TO MAKE IN PubWorld.jsx:
  ══════════════════════════════════

  1. Import at top:
       import { VoxelVolume } from './voxel_culling';

  2. Replace:
       const voxMap = new Map();
     With:
       const volume = new VoxelVolume();

  3. Replace placeVoxel():
       function placeVoxel(x, y, z) {
         const k = vKey(x, y, z);
         if (volume.has(x, y, z)) return;
         const hex = parseInt(palRef.current.slice(1), 16);
         volume.place(x, y, z, { color: hex });
         syncShellToScene(volume, scene, voxMap);
         setVoxCount(volume.size);
         const s = volume.stats();
         setStatus(`PLACED · (${Math.round(x)},${Math.round(y-0.5)},${Math.round(z)}) · ${s.shell} rendered · ${s.culled} interior culled`);
       }

  4. Add syncShellToScene():
       function syncShellToScene(volume, scene, meshCache) {
         // Remove meshes no longer in shell
         meshCache.forEach((mesh, key) => {
           if (!volume.shell.has(key)) {
             scene.remove(mesh);
             mesh.geometry.dispose(); mesh.material.dispose();
             meshCache.delete(key);
           }
         });
         // Add new shell voxels
         volume.shellEntries().forEach(v => {
           if (meshCache.has(v.key)) return;
           const mesh = new THREE.Mesh(
             new THREE.BoxGeometry(0.96, 0.96, 0.96),
             new THREE.MeshStandardMaterial({ color: v.color, roughness: 0.65, metalness: 0.06 })
           );
           mesh.position.set(v.x, v.y, v.z);
           mesh.castShadow = mesh.receiveShadow = true;
           scene.add(mesh);
           meshCache.set(v.key, mesh);
         });
       }

  5. Replace removeVoxelAt() to call volume.remove() then syncShellToScene().

  6. Status bar: show volume.stats().culled to make the savings visible.
     e.g. "847 voxels · 312 rendered · 535 interior (hollow)"

  7. handleBake() — call volume.toJSON(setName) for the backend POST.
     The JSON only contains shell voxels. Interior never sent to server.
*/
